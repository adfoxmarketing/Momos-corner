//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D0kKXP_N.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CJsoxYJc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CJsoxYJc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-wjTyAMj8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
