import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Check, b as Bell, c as Sun, d as Moon, f as LayoutGrid, g as ChevronLeft, h as ChevronRight, i as Wallet, l as Plus, m as Download, n as ZoomOut, o as Trash2, p as GraduationCap, r as X, s as Table2, t as ZoomIn, u as Paperclip, v as CalendarDays, x as ArrowLeftRight, y as BookOpen } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B3VHG5jG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DB_NAME = "school_manager";
var DB_VERSION = 1;
var STORES = [
	"subjects",
	"class_slots",
	"tasks",
	"attachments",
	"student_grades",
	"calendar_notes",
	"teacher_sections",
	"teacher_terms",
	"teacher_grades",
	"tutoring_students"
];
var opening = null;
function openDb() {
	if (typeof indexedDB === "undefined") return Promise.reject(/* @__PURE__ */ new Error("IndexedDB unavailable"));
	if (opening) return opening;
	opening = new Promise((resolve, reject) => {
		const request = indexedDB.open(DB_NAME, DB_VERSION);
		request.onupgradeneeded = () => {
			const db = request.result;
			if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta");
			for (const name of STORES) if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, {
				keyPath: "id",
				autoIncrement: true
			});
			const tx = request.transaction;
			if (!tx) return;
			const notes = tx.objectStore("calendar_notes");
			if (!notes.indexNames.contains("date")) notes.createIndex("date", "date", { unique: true });
			const grades = tx.objectStore("student_grades");
			if (!grades.indexNames.contains("subject_id")) grades.createIndex("subject_id", "subject_id", { unique: true });
		};
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => {
			opening = null;
			reject(request.error ?? /* @__PURE__ */ new Error("Failed to open database"));
		};
	});
	return opening;
}
function finish(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("Transaction failed"));
		tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("Transaction aborted"));
	});
}
async function getMeta(key) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const request = db.transaction("meta", "readonly").objectStore("meta").get(key);
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("Meta read failed"));
	});
}
async function setMeta(key, value) {
	const tx = (await openDb()).transaction("meta", "readwrite");
	tx.objectStore("meta").put(value, key);
	await finish(tx);
}
async function getAllRows(store) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const request = db.transaction(store, "readonly").objectStore(store).getAll();
		request.onsuccess = () => resolve(request.result ?? []);
		request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("Read failed"));
	});
}
async function addRow(store, value) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const request = db.transaction(store, "readwrite").objectStore(store).add(value);
		request.onsuccess = () => resolve({
			...value,
			id: request.result
		});
		request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("Add failed"));
	});
}
async function putRow(store, value) {
	const tx = (await openDb()).transaction(store, "readwrite");
	tx.objectStore(store).put(value);
	await finish(tx);
}
async function deleteRow(store, id) {
	const tx = (await openDb()).transaction(store, "readwrite");
	tx.objectStore(store).delete(id);
	await finish(tx);
}
async function deleteWhere(store, pred) {
	const tx = (await openDb()).transaction(store, "readwrite");
	const request = tx.objectStore(store).openCursor();
	request.onsuccess = () => {
		const cursor = request.result;
		if (!cursor) return;
		if (pred(cursor.value)) cursor.delete();
		cursor.continue();
	};
	await finish(tx);
}
var dictionaries = {
	en: {
		appName: "School Manager",
		appNameAlt: "مدير المدرسة",
		tagline: "Timetable, grades, and tutoring — stored only on this device.",
		activateTitle: "Activate your license",
		activateHint: "Enter the license key to unlock the app on this device.",
		licenseLabel: "License key",
		licensePlaceholder: "XXXX-XXXX-XXXX",
		activate: "Activate",
		invalidLicense: "That key is not valid.",
		devKey: "Developer key: TEST-DEV-2024",
		roleTitle: "Who is using this device?",
		roleHint: "You can switch later. Everything stays on this device.",
		teacher: "Teacher",
		student: "Student",
		teacherBlurb: "Plan a schedule, keep a gradebook, and track tutoring payments.",
		studentBlurb: "Build a timetable, record marks, and jot calendar notes.",
		timetable: "Timetable",
		averages: "Averages",
		calendar: "Calendar",
		grading: "Gradebook",
		tutoring: "Tutoring",
		switchRole: "Switch role",
		switchRoleTitle: "Switch role?",
		switchRoleBody: "Your timetable, grades, and notes stay saved on this device.",
		lightMode: "Light mode",
		darkMode: "Dark mode",
		language: "Language",
		zoomIn: "Zoom in",
		zoomOut: "Zoom out",
		zoomReset: "Reset zoom",
		fromTo: "08:00 – 21:00",
		addClass: "Add class",
		subject: "Subject",
		teacherName: "Teacher",
		day: "Day",
		start: "Start",
		end: "End",
		coefficient: "Coefficient",
		color: "Color",
		colorShared: "Color and coefficient are shared by every class of this subject.",
		save: "Save",
		cancel: "Cancel",
		delete: "Delete",
		close: "Close",
		required: "Fill in the required fields.",
		timeOrder: "End time must be after the start time.",
		addTask: "Add task",
		addFile: "Add file",
		deleteClass: "Delete class",
		confirmDeleteClass: "Remove this class from the timetable? Tasks and files stay on the subject.",
		tasks: "Tasks",
		files: "Files",
		taskTitle: "Task title",
		dueDate: "Due date",
		noTasks: "No tasks for this subject yet.",
		noFiles: "No files for this subject yet.",
		reminderSet: "Saved. A reminder is set for the day before it is due.",
		reminderOff: "Saved. Allow notifications to get a reminder the day before.",
		reminderTitle: "School Manager",
		reminderBody: "{title} is due on {date}",
		uploadDate: "Added",
		open: "Open",
		image: "Image",
		pdf: "PDF",
		fileTitle: "File title",
		pickImage: "Choose image",
		pickPdf: "Choose PDF",
		noClassesHint: "Tap an empty cell to add a class. Pinch or use the buttons to zoom.",
		upcoming: "Open tasks",
		averagesHint: "Subjects come from the timetable. CC, TP, Dev 1, and Dev 2 count once; the exam counts double. Empty cells are skipped. The general average uses each subject’s coefficient.",
		generalAverage: "General average",
		outOf: "out of 20",
		noSubjects: "Add classes on the timetable and their subjects will appear here.",
		invalidMark: "Enter a mark from 0 to 20.",
		notePlaceholder: "Write a note for this day…",
		clearNote: "Clear note",
		saved: "Saved",
		sections: "Section",
		terms: "Term",
		addSection: "Add section",
		addTerm: "Add term",
		sectionName: "Section name",
		termName: "Term name",
		deleteSection: "Delete section",
		deleteTerm: "Delete term",
		confirmDeleteSection: "Delete this section and every grade stored in it?",
		confirmDeleteTerm: "Delete this term and every grade stored in it?",
		students: "Students",
		addStudent: "Add student",
		studentName: "Student name",
		noStudents: "No students in this section and term yet.",
		needSectionTerm: "Add a section and a term before entering students.",
		exportExcel: "Export Excel",
		exported: "Gradebook exported.",
		shared: "Gradebook ready to share.",
		editGrades: "Marks",
		paid: "Paid",
		total: "Total",
		remaining: "Remaining",
		group: "Group",
		location: "Location",
		addTutoring: "Add tutoring student",
		tutoringHint: "Track what was agreed and what has been paid. The balance updates itself.",
		noTutoring: "No tutoring students yet.",
		billed: "Agreed",
		collected: "Collected",
		outstanding: "Outstanding",
		settled: "Settled",
		dueBalance: "Due",
		updatePaid: "Update payment",
		deleteStudent: "Delete student",
		confirmDeleteStudent: "Remove this student and their marks?",
		confirmDeleteTutoring: "Remove this tutoring record?",
		amountInvalid: "Enter a valid amount of zero or more.",
		classSaved: "Class added.",
		deleted: "Deleted.",
		errorGeneric: "Something went wrong. Try again.",
		loading: "Opening your school book…",
		bootError: "Could not open on-device storage.",
		bootErrorAlt: "تعذر فتح التخزين على الجهاز.",
		markDone: "Mark done",
		markOpen: "Mark not done",
		download: "Download",
		preview: "Preview",
		chooseFile: "Choose a file first.",
		today: "Today",
		coefShort: "coef",
		cc: "CC",
		tp: "TP",
		dev1: "Dev 1",
		dev2: "Dev 2",
		exam: "Exam",
		average: "Average",
		noneYet: "Nothing here yet.",
		back: "Back",
		confirm: "Confirm",
		roleStudent: "Student",
		roleTeacher: "Teacher"
	},
	ar: {
		appName: "مدير المدرسة",
		appNameAlt: "School Manager",
		tagline: "الجدول والعلامات والدعم — محفوظة على هذا الجهاز فقط.",
		activateTitle: "تفعيل الترخيص",
		activateHint: "أدخل مفتاح الترخيص لفتح التطبيق على هذا الجهاز.",
		licenseLabel: "مفتاح الترخيص",
		licensePlaceholder: "XXXX-XXXX-XXXX",
		activate: "تفعيل",
		invalidLicense: "هذا المفتاح غير صالح.",
		devKey: "مفتاح التجربة: TEST-DEV-2024",
		roleTitle: "من يستخدم هذا الجهاز؟",
		roleHint: "يمكنك التبديل لاحقًا. كل البيانات تبقى على الجهاز.",
		teacher: "أستاذ",
		student: "طالب",
		teacherBlurb: "رتّب جدولك، وسجّل العلامات، وتابع مدفوعات الدعم.",
		studentBlurb: "ابنِ جدولك، وسجّل نقاطك، ودوّن ملاحظات التقويم.",
		timetable: "الجدول",
		averages: "المعدلات",
		calendar: "التقويم",
		grading: "العلامات",
		tutoring: "الدعم",
		switchRole: "تبديل الدور",
		switchRoleTitle: "تبديل الدور؟",
		switchRoleBody: "الجدول والعلامات والملاحظات تبقى محفوظة على هذا الجهاز.",
		lightMode: "الوضع الفاتح",
		darkMode: "الوضع الداكن",
		language: "اللغة",
		zoomIn: "تكبير",
		zoomOut: "تصغير",
		zoomReset: "إعادة التكبير",
		fromTo: "08:00 – 21:00",
		addClass: "إضافة حصة",
		subject: "المادة",
		teacherName: "الأستاذ",
		day: "اليوم",
		start: "البداية",
		end: "النهاية",
		coefficient: "المعامل",
		color: "اللون",
		colorShared: "اللون والمعامل مشتركان بين كل حصص هذه المادة.",
		save: "حفظ",
		cancel: "إلغاء",
		delete: "حذف",
		close: "إغلاق",
		required: "أكمل الحقول المطلوبة.",
		timeOrder: "وقت النهاية يجب أن يكون بعد البداية.",
		addTask: "إضافة مهمة",
		addFile: "إضافة ملف",
		deleteClass: "حذف الحصة",
		confirmDeleteClass: "حذف هذه الحصة من الجدول؟ المهام والملفات تبقى مرتبطة بالمادة.",
		tasks: "المهام",
		files: "الملفات",
		taskTitle: "عنوان المهمة",
		dueDate: "تاريخ الاستحقاق",
		noTasks: "لا مهام لهذه المادة بعد.",
		noFiles: "لا ملفات لهذه المادة بعد.",
		reminderSet: "تم الحفظ. سيصلك تذكير قبل يوم من الموعد.",
		reminderOff: "تم الحفظ. اسمح بالإشعارات ليصلك تذكير قبل الموعد بيوم.",
		reminderTitle: "مدير المدرسة",
		reminderBody: "{title} مستحق في {date}",
		uploadDate: "أُضيف",
		open: "فتح",
		image: "صورة",
		pdf: "PDF",
		fileTitle: "عنوان الملف",
		pickImage: "اختيار صورة",
		pickPdf: "اختيار PDF",
		noClassesHint: "اضغط خانة فارغة لإضافة حصة. قرّب بإصبعين أو بأزرار التكبير.",
		upcoming: "مهام مفتوحة",
		averagesHint: "المواد تُؤخذ من الجدول. المراقبة والتطبيق والفرضان بوزن 1، والامتحان بوزن 2. الخانات الفارغة تُتجاهل. المعدل العام يراعي معامل كل مادة.",
		generalAverage: "المعدل العام",
		outOf: "من 20",
		noSubjects: "أضف حصصًا في الجدول وستظهر موادها هنا.",
		invalidMark: "أدخل علامة من 0 إلى 20.",
		notePlaceholder: "اكتب ملاحظة لهذا اليوم…",
		clearNote: "مسح الملاحظة",
		saved: "تم الحفظ",
		sections: "القسم",
		terms: "الفصل",
		addSection: "إضافة قسم",
		addTerm: "إضافة فصل",
		sectionName: "اسم القسم",
		termName: "اسم الفصل",
		deleteSection: "حذف القسم",
		deleteTerm: "حذف الفصل",
		confirmDeleteSection: "حذف هذا القسم وكل العلامات المحفوظة فيه؟",
		confirmDeleteTerm: "حذف هذا الفصل وكل العلامات المحفوظة فيه؟",
		students: "الطلاب",
		addStudent: "إضافة طالب",
		studentName: "اسم الطالب",
		noStudents: "لا طلاب في هذا القسم والفصل بعد.",
		needSectionTerm: "أضف قسمًا وفصلًا قبل إدخال الطلاب.",
		exportExcel: "تصدير إكسل",
		exported: "تم تصدير العلامات.",
		shared: "ملف العلامات جاهز للمشاركة.",
		editGrades: "العلامات",
		paid: "المدفوع",
		total: "الإجمالي",
		remaining: "المتبقي",
		group: "الفوج",
		location: "المكان",
		addTutoring: "إضافة طالب دعم",
		tutoringHint: "سجّل المبلغ المتفق عليه وما دُفع. الرصيد يُحسب تلقائيًا.",
		noTutoring: "لا طلاب دعم بعد.",
		billed: "المتفق عليه",
		collected: "المحصّل",
		outstanding: "المتبقي",
		settled: "خالص",
		dueBalance: "مستحق",
		updatePaid: "تحديث الدفع",
		deleteStudent: "حذف الطالب",
		confirmDeleteStudent: "حذف هذا الطالب وعلاماته؟",
		confirmDeleteTutoring: "حذف سجل الدعم هذا؟",
		amountInvalid: "أدخل مبلغًا صحيحًا من صفر فأكثر.",
		classSaved: "تمت إضافة الحصة.",
		deleted: "تم الحذف.",
		errorGeneric: "حدث خطأ. حاول مرة أخرى.",
		loading: "جارٍ فتح سجل المدرسة…",
		bootError: "تعذر فتح التخزين على الجهاز.",
		bootErrorAlt: "Could not open on-device storage.",
		markDone: "تعليم كمكتملة",
		markOpen: "تعليم كغير مكتملة",
		download: "تنزيل",
		preview: "معاينة",
		chooseFile: "اختر ملفًا أولًا.",
		today: "اليوم",
		coefShort: "معامل",
		cc: "CC",
		tp: "TP",
		dev1: "فرض 1",
		dev2: "فرض 2",
		exam: "الامتحان",
		average: "المعدل",
		noneYet: "لا شيء هنا بعد.",
		back: "رجوع",
		confirm: "تأكيد",
		roleStudent: "طالب",
		roleTeacher: "أستاذ"
	}
};
function translate(lang, key, vars) {
	let text = dictionaries[lang][key];
	if (vars) for (const [name, value] of Object.entries(vars)) text = text.replaceAll(`{${name}}`, String(value));
	return text;
}
var DAY_END = 1260;
var SUBJECT_COLORS = [
	"#1e4d3a",
	"#a24b24",
	"#1d4e89",
	"#6b3fa0",
	"#8a5a12",
	"#0f6e6b",
	"#9b2c4a",
	"#3f6212"
];
function localeOf(lang) {
	return lang === "ar" ? "ar-u-nu-latn" : "en";
}
function toHHMM(mins) {
	const clamped = Math.max(0, mins);
	const h = Math.floor(clamped / 60);
	const m = clamped % 60;
	return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
function toMin(hhmm) {
	const [h, m] = hhmm.split(":").map((part) => Number(part));
	if (!Number.isFinite(h) || !Number.isFinite(m)) return 480;
	return h * 60 + m;
}
function timeOptions() {
	const out = [];
	for (let m = 480; m <= DAY_END; m += 30) out.push(toHHMM(m));
	return out;
}
function hourLabels() {
	return Array.from({ length: 13 }, (_, i) => 8 + i);
}
function weekdayName(lang, dayOfWeek, width = "short") {
	const date = new Date(2023, 0, dayOfWeek);
	return new Intl.DateTimeFormat(localeOf(lang), { weekday: width }).format(date);
}
function monthName(lang, monthIndex, width = "short") {
	return new Intl.DateTimeFormat(localeOf(lang), { month: width }).format(new Date(2023, monthIndex, 1));
}
function formatDate(lang, iso) {
	const [y, m, d] = iso.split("-").map(Number);
	if (!y || !m || !d) return iso;
	return new Intl.DateTimeFormat(localeOf(lang), { dateStyle: "medium" }).format(new Date(y, m - 1, d));
}
function formatMark(lang, value) {
	return new Intl.NumberFormat(localeOf(lang), { maximumFractionDigits: 2 }).format(value);
}
function formatMoney(lang, value) {
	return new Intl.NumberFormat(localeOf(lang), {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	}).format(value);
}
function isoDate(year, monthIndex, day) {
	return `${year}-${String(monthIndex + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}
function tomorrowIso() {
	const now = /* @__PURE__ */ new Date();
	now.setDate(now.getDate() + 1);
	return isoDate(now.getFullYear(), now.getMonth(), now.getDate());
}
function reminderTime(dueIso) {
	const [y, m, d] = dueIso.split("-").map(Number);
	const when = new Date(y || 1970, (m || 1) - 1, d || 1, 9, 0, 0, 0);
	when.setDate(when.getDate() - 1);
	return when.getTime();
}
function foregroundFor(hex) {
	const raw = hex.replace("#", "");
	if (!/^[0-9a-fA-F]{6}$/.test(raw)) return "#1c1915";
	const n = Number.parseInt(raw, 16);
	const r = n >> 16 & 255;
	const g = n >> 8 & 255;
	const b = n & 255;
	return (.2126 * r + .7152 * g + .0722 * b) / 255 > .64 ? "#1c1915" : "#f7f4ee";
}
function parseMark(raw) {
	const text = raw.trim().replace(",", ".");
	if (!text) return null;
	const n = Number(text);
	if (!Number.isFinite(n) || n < 0 || n > 20) return "invalid";
	return Math.round(n * 100) / 100;
}
function parseAmount(raw) {
	const text = raw.trim().replace(",", ".");
	if (!text) return "invalid";
	const n = Number(text);
	if (!Number.isFinite(n) || n < 0) return "invalid";
	return Math.round(n * 100) / 100;
}
function csvCell(value) {
	const text = value == null ? "" : String(value);
	if (/[",\n\r]/.test(text)) return `"${text.replaceAll("\"", "\"\"")}"`;
	return text;
}
async function shareCsv(filename, rows) {
	const csv = rows.map((row) => row.map((cell) => csvCell(cell)).join(",")).join("\r\n");
	const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
	const file = new File([blob], filename, { type: "text/csv" });
	try {
		if (typeof navigator.share === "function" && navigator.canShare?.({ files: [file] })) {
			await navigator.share({
				files: [file],
				title: filename
			});
			return "shared";
		}
	} catch (error) {
		if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
	}
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
	return "downloaded";
}
function clampZoom(value) {
	return Math.min(1.8, Math.max(.7, Math.round(value * 100) / 100));
}
function haptic(ms = 12) {
	try {
		navigator.vibrate?.(ms);
	} catch {}
}
var MARK_FIELDS = [
	"cc",
	"tp",
	"dev1",
	"dev2",
	"exam"
];
function emptyMarks() {
	return {
		cc: null,
		tp: null,
		dev1: null,
		dev2: null,
		exam: null
	};
}
var DEFAULT_SETTINGS = {
	activated: false,
	role: null,
	theme: "light",
	lang: "en",
	reminded: []
};
var initialState = {
	ready: false,
	bootError: false,
	settings: DEFAULT_SETTINGS,
	subjects: [],
	slots: [],
	tasks: [],
	attachments: [],
	grades: [],
	notes: [],
	sections: [],
	terms: [],
	teacherGrades: [],
	tutoring: [],
	toast: null
};
var SchoolContext = (0, import_react.createContext)(null);
function detectedSettings() {
	const theme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
	const lang = navigator.language.toLowerCase().startsWith("ar") ? "ar" : "en";
	return {
		...DEFAULT_SETTINGS,
		theme,
		lang
	};
}
async function ensureNotifyPermission() {
	if (typeof Notification === "undefined") return false;
	if (Notification.permission === "granted") return true;
	if (Notification.permission === "denied") return false;
	try {
		return await Notification.requestPermission() === "granted";
	} catch {
		return false;
	}
}
function SchoolProvider({ children }) {
	const [state, setState] = (0, import_react.useState)(initialState);
	const dataRef = (0, import_react.useRef)(state);
	const queue = (0, import_react.useRef)(Promise.resolve());
	const toastTimer = (0, import_react.useRef)(null);
	const patch = (fn) => {
		setState((current) => {
			const next = fn(current);
			dataRef.current = next;
			return next;
		});
	};
	const flash = (message) => {
		patch((current) => ({
			...current,
			toast: message
		}));
		if (toastTimer.current) window.clearTimeout(toastTimer.current);
		toastTimer.current = window.setTimeout(() => {
			patch((current) => ({
				...current,
				toast: null
			}));
		}, 2600);
	};
	const enqueue = (fn) => {
		const run = queue.current.then(fn, fn);
		queue.current = run.then(() => void 0, () => void 0);
		return run;
	};
	const writeSettings = async (next) => {
		patch((current) => ({
			...current,
			settings: next
		}));
		await setMeta("settings", next);
	};
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			try {
				const [saved, subjects, slots, tasks, attachments, grades, notes, sections, terms, teacherGrades, tutoring] = await Promise.all([
					getMeta("settings"),
					getAllRows("subjects"),
					getAllRows("class_slots"),
					getAllRows("tasks"),
					getAllRows("attachments"),
					getAllRows("student_grades"),
					getAllRows("calendar_notes"),
					getAllRows("teacher_sections"),
					getAllRows("teacher_terms"),
					getAllRows("teacher_grades"),
					getAllRows("tutoring_students")
				]);
				if (cancelled) return;
				const settings = saved ? {
					...DEFAULT_SETTINGS,
					...saved,
					reminded: saved.reminded ?? []
				} : detectedSettings();
				patch((current) => ({
					...current,
					ready: true,
					settings,
					subjects,
					slots,
					tasks,
					attachments,
					grades,
					notes,
					sections,
					terms,
					teacherGrades,
					tutoring
				}));
			} catch (error) {
				console.error(error);
				if (!cancelled) patch((current) => ({
					...current,
					ready: true,
					bootError: true
				}));
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!state.ready) return;
		document.documentElement.classList.toggle("dark", state.settings.theme === "dark");
		document.documentElement.lang = state.settings.lang === "ar" ? "ar" : "en";
		document.documentElement.dir = state.settings.lang === "ar" ? "rtl" : "ltr";
		try {
			localStorage.setItem("sm-theme", state.settings.theme);
			localStorage.setItem("sm-lang", state.settings.lang);
		} catch {}
	}, [
		state.ready,
		state.settings.theme,
		state.settings.lang
	]);
	(0, import_react.useEffect)(() => {
		if (!state.ready) return;
		let cancelled = false;
		const run = () => {
			enqueue(async () => {
				if (cancelled) return;
				const current = dataRef.current;
				const due = current.tasks.filter((task) => {
					if (task.is_completed || current.settings.reminded.includes(task.id)) return false;
					return Date.now() >= reminderTime(task.due_date);
				});
				if (!due.length) return;
				const permitted = typeof Notification !== "undefined" && Notification.permission === "granted";
				const lang = current.settings.lang;
				const message = translate(lang, "reminderBody", {
					title: due[0].title,
					date: formatDate(lang, due[0].due_date)
				});
				for (const task of due) {
					const body = translate(lang, "reminderBody", {
						title: task.title,
						date: formatDate(lang, task.due_date)
					});
					if (permitted) try {
						new Notification(translate(lang, "reminderTitle"), { body });
					} catch {}
				}
				const reminded = [...current.settings.reminded, ...due.map((task) => task.id)];
				const next = {
					...current.settings,
					reminded
				};
				patch((snapshot) => ({
					...snapshot,
					settings: next,
					toast: message
				}));
				if (toastTimer.current) window.clearTimeout(toastTimer.current);
				toastTimer.current = window.setTimeout(() => {
					patch((snapshot) => ({
						...snapshot,
						toast: null
					}));
				}, 3200);
				await setMeta("settings", next);
			});
		};
		run();
		const id = window.setInterval(run, 3e4);
		return () => {
			cancelled = true;
			window.clearInterval(id);
		};
	}, [
		state.ready,
		state.tasks,
		state.settings.reminded,
		state.settings.lang
	]);
	const api = (0, import_react.useMemo)(() => {
		return {
			...state,
			flash,
			activate: async (key) => {
				if (key.trim().toUpperCase() !== "TEST-DEV-2024") return false;
				await enqueue(() => writeSettings({
					...dataRef.current.settings,
					activated: true
				}));
				return true;
			},
			setRole: (role) => enqueue(() => writeSettings({
				...dataRef.current.settings,
				role
			})),
			setLang: (lang) => enqueue(() => writeSettings({
				...dataRef.current.settings,
				lang
			})),
			setTheme: (theme) => enqueue(() => writeSettings({
				...dataRef.current.settings,
				theme
			})),
			saveClass: (input) => enqueue(async () => {
				const current = dataRef.current;
				const name = input.name.trim();
				const teacher = input.teacher.trim();
				const existing = current.subjects.find((subject) => subject.name.trim().toLowerCase() === name.toLowerCase());
				let subjectId;
				let subjects = current.subjects;
				if (existing) {
					const updated = {
						...existing,
						teacher,
						color: input.color,
						coefficient: input.coefficient
					};
					await putRow("subjects", updated);
					subjects = subjects.map((subject) => subject.id === updated.id ? updated : subject);
					subjectId = updated.id;
				} else {
					const created = await addRow("subjects", {
						name,
						teacher,
						color: input.color,
						coefficient: input.coefficient
					});
					subjects = [...subjects, created];
					subjectId = created.id;
				}
				const slot = await addRow("class_slots", {
					subject_id: subjectId,
					day_of_week: input.day,
					start_time: input.start,
					end_time: input.end
				});
				patch((snapshot) => ({
					...snapshot,
					subjects,
					slots: [...snapshot.slots, slot]
				}));
			}),
			deleteSlot: (id) => enqueue(async () => {
				await deleteRow("class_slots", id);
				patch((snapshot) => ({
					...snapshot,
					slots: snapshot.slots.filter((slot) => slot.id !== id)
				}));
			}),
			addTask: async (input) => {
				const permitted = await ensureNotifyPermission();
				await enqueue(async () => {
					const task = await addRow("tasks", {
						subject_id: input.subjectId,
						title: input.title.trim(),
						due_date: input.due,
						is_completed: false
					});
					patch((snapshot) => ({
						...snapshot,
						tasks: [...snapshot.tasks, task]
					}));
				});
				return permitted;
			},
			toggleTask: (id, done) => enqueue(async () => {
				const task = dataRef.current.tasks.find((item) => item.id === id);
				if (!task) return;
				const next = {
					...task,
					is_completed: done
				};
				await putRow("tasks", next);
				patch((snapshot) => ({
					...snapshot,
					tasks: snapshot.tasks.map((item) => item.id === id ? next : item)
				}));
			}),
			deleteTask: (id) => enqueue(async () => {
				await deleteRow("tasks", id);
				patch((snapshot) => ({
					...snapshot,
					tasks: snapshot.tasks.filter((task) => task.id !== id)
				}));
			}),
			addAttachment: (input) => enqueue(async () => {
				const today = /* @__PURE__ */ new Date();
				const upload_date = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
				const row = await addRow("attachments", {
					subject_id: input.subjectId,
					title: input.title.trim(),
					type: input.type,
					file_path: input.filename,
					upload_date,
					blob: input.file
				});
				patch((snapshot) => ({
					...snapshot,
					attachments: [...snapshot.attachments, row]
				}));
			}),
			deleteAttachment: (id) => enqueue(async () => {
				await deleteRow("attachments", id);
				patch((snapshot) => ({
					...snapshot,
					attachments: snapshot.attachments.filter((file) => file.id !== id)
				}));
			}),
			setStudentMark: (subjectId, field, value) => enqueue(async () => {
				const existing = dataRef.current.grades.find((grade) => grade.subject_id === subjectId);
				if (!existing) {
					const created = await addRow("student_grades", {
						subject_id: subjectId,
						...emptyMarks(),
						[field]: value
					});
					patch((snapshot) => ({
						...snapshot,
						grades: [...snapshot.grades, created]
					}));
					return;
				}
				const next = {
					...existing,
					[field]: value
				};
				await putRow("student_grades", next);
				patch((snapshot) => ({
					...snapshot,
					grades: snapshot.grades.map((grade) => grade.id === next.id ? next : grade)
				}));
			}),
			saveNote: (date, note) => enqueue(async () => {
				const text = note.trim();
				const existing = dataRef.current.notes.find((item) => item.date === date);
				if (!text) {
					if (!existing) return;
					await deleteRow("calendar_notes", existing.id);
					patch((snapshot) => ({
						...snapshot,
						notes: snapshot.notes.filter((item) => item.id !== existing.id)
					}));
					return;
				}
				if (existing) {
					const next = {
						...existing,
						note: text
					};
					await putRow("calendar_notes", next);
					patch((snapshot) => ({
						...snapshot,
						notes: snapshot.notes.map((item) => item.id === next.id ? next : item)
					}));
					return;
				}
				const created = await addRow("calendar_notes", {
					date,
					note: text
				});
				patch((snapshot) => ({
					...snapshot,
					notes: [...snapshot.notes, created]
				}));
			}),
			addSection: (name) => enqueue(async () => {
				const row = await addRow("teacher_sections", { name: name.trim() });
				patch((snapshot) => ({
					...snapshot,
					sections: [...snapshot.sections, row]
				}));
			}),
			deleteSection: (id) => enqueue(async () => {
				await deleteWhere("teacher_grades", (row) => row.section_id === id);
				await deleteRow("teacher_sections", id);
				patch((snapshot) => ({
					...snapshot,
					sections: snapshot.sections.filter((section) => section.id !== id),
					teacherGrades: snapshot.teacherGrades.filter((grade) => grade.section_id !== id)
				}));
			}),
			addTerm: (name) => enqueue(async () => {
				const row = await addRow("teacher_terms", { name: name.trim() });
				patch((snapshot) => ({
					...snapshot,
					terms: [...snapshot.terms, row]
				}));
			}),
			deleteTerm: (id) => enqueue(async () => {
				await deleteWhere("teacher_grades", (row) => row.term_id === id);
				await deleteRow("teacher_terms", id);
				patch((snapshot) => ({
					...snapshot,
					terms: snapshot.terms.filter((term) => term.id !== id),
					teacherGrades: snapshot.teacherGrades.filter((grade) => grade.term_id !== id)
				}));
			}),
			addTeacherStudent: (input) => enqueue(async () => {
				const row = await addRow("teacher_grades", {
					section_id: input.sectionId,
					term_id: input.termId,
					student_name: input.name.trim(),
					...emptyMarks()
				});
				patch((snapshot) => ({
					...snapshot,
					teacherGrades: [...snapshot.teacherGrades, row]
				}));
			}),
			updateTeacherGrade: (row) => enqueue(async () => {
				await putRow("teacher_grades", row);
				patch((snapshot) => ({
					...snapshot,
					teacherGrades: snapshot.teacherGrades.map((grade) => grade.id === row.id ? row : grade)
				}));
			}),
			deleteTeacherGrade: (id) => enqueue(async () => {
				await deleteRow("teacher_grades", id);
				patch((snapshot) => ({
					...snapshot,
					teacherGrades: snapshot.teacherGrades.filter((grade) => grade.id !== id)
				}));
			}),
			addTutoring: (input) => enqueue(async () => {
				const row = await addRow("tutoring_students", {
					...input,
					paid_amount: 0
				});
				patch((snapshot) => ({
					...snapshot,
					tutoring: [...snapshot.tutoring, row]
				}));
			}),
			updateTutoring: (row) => enqueue(async () => {
				await putRow("tutoring_students", row);
				patch((snapshot) => ({
					...snapshot,
					tutoring: snapshot.tutoring.map((student) => student.id === row.id ? row : student)
				}));
			}),
			deleteTutoring: (id) => enqueue(async () => {
				await deleteRow("tutoring_students", id);
				patch((snapshot) => ({
					...snapshot,
					tutoring: snapshot.tutoring.filter((student) => student.id !== id)
				}));
			})
		};
	}, [state]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchoolContext.Provider, {
		value: api,
		children
	});
}
function useSchool() {
	const ctx = (0, import_react.useContext)(SchoolContext);
	if (!ctx) throw new Error("useSchool must be used inside SchoolProvider");
	return ctx;
}
function useT() {
	const { settings } = useSchool();
	return (key, vars) => translate(settings.lang, key, vars);
}
var fieldClass = "h-11 w-full rounded-lg border border-border bg-bg px-3 text-base text-fg";
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 48",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 22 24 10l16 12",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 21.5V38h24V21.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M21 38V28h6v10",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.5"
			})
		]
	});
}
function IconButton({ label, onClick, children, pressed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		"aria-pressed": pressed,
		onClick,
		className: "press grid size-11 place-items-center rounded-full text-fg hover:bg-surface-2",
		children
	});
}
function PrimaryButton({ children, onClick, type = "button", disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		disabled,
		onClick,
		className: "press inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg disabled:opacity-50",
		children
	});
}
function GhostButton({ children, onClick, danger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `press inline-flex h-11 items-center justify-center gap-2 rounded-lg border px-4 text-sm font-semibold ${danger ? "border-danger text-danger" : "border-border bg-surface text-fg"}`,
		children
	});
}
function Modal({ title, onClose, children }) {
	const t = useT();
	const panel = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		panel.current?.focus();
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = previous;
			window.removeEventListener("keydown", onKey);
		};
	}, [onClose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stage-3d fixed inset-0 z-50 flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": t("close"),
			className: "absolute inset-0 bg-fg/40 backdrop-blur-md",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: panel,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			tabIndex: -1,
			className: "panel-3d animate-rise relative max-h-[92dvh] w-full overflow-y-auto rounded-t-2xl border border-border bg-surface sm:max-w-md sm:rounded-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center gap-2 border-b border-border bg-surface px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "min-w-0 flex-1 truncate text-base font-bold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": t("close"),
					onClick: onClose,
					className: "press grid size-11 place-items-center rounded-full hover:bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 py-4",
				children
			})]
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-3 block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-sm font-medium",
			children: label
		}), children]
	});
}
var WEIGHTS = {
	cc: 1,
	tp: 1,
	dev1: 1,
	dev2: 1,
	exam: 2
};
function averageOf(marks) {
	let sum = 0;
	let weight = 0;
	Object.keys(WEIGHTS).forEach((field) => {
		const value = marks[field];
		if (value == null || Number.isNaN(value)) return;
		sum += value * WEIGHTS[field];
		weight += WEIGHTS[field];
	});
	if (weight === 0) return null;
	return sum / weight;
}
function generalAverage(items) {
	let sum = 0;
	let coef = 0;
	for (const item of items) {
		if (item.average == null) continue;
		const weight = item.coefficient > 0 ? item.coefficient : 1;
		sum += item.average * weight;
		coef += weight;
	}
	if (coef === 0) return null;
	return sum / coef;
}
function Averages() {
	const school = useSchool();
	const t = useT();
	const orderedIds = [];
	const slots = [...school.slots].sort((a, b) => a.day_of_week - b.day_of_week || a.start_time.localeCompare(b.start_time));
	for (const slot of slots) if (!orderedIds.includes(slot.subject_id)) orderedIds.push(slot.subject_id);
	const rows = orderedIds.map((id) => school.subjects.find((subject) => subject.id === id)).filter((subject) => subject != null).map((subject) => {
		const grade = school.grades.find((item) => item.subject_id === subject.id);
		const marks = {
			cc: grade?.cc ?? null,
			tp: grade?.tp ?? null,
			dev1: grade?.dev1 ?? null,
			dev2: grade?.dev2 ?? null,
			exam: grade?.exam ?? null
		};
		return {
			subject,
			marks,
			average: averageOf(marks)
		};
	});
	const overall = generalAverage(rows.map((row) => ({
		average: row.average,
		coefficient: row.subject.coefficient
	})));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "ledger-card mb-4 rounded-2xl p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: t("generalAverage")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-4xl font-extrabold tabular-nums",
					children: overall == null ? "—" : formatMark(school.settings.lang, overall)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm opacity-80",
					children: t("outOf")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: t("averagesHint")
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted",
			children: t("noSubjects")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-xl border border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[760px] border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-surface-2 text-start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "sticky start-0 z-10 bg-surface-2 px-3 py-2 text-start font-semibold",
						children: t("subject")
					}), [
						t("cc"),
						t("tp"),
						t("dev1"),
						t("dev2"),
						t("exam"),
						t("average")
					].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2 text-start font-semibold",
						children: label
					}, label))] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "sticky start-0 z-10 bg-surface px-3 py-2 text-start font-semibold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2.5 rounded-full",
									style: { background: row.subject.color }
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [row.subject.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs font-normal text-muted",
									children: [
										t("coefShort"),
										" ",
										row.subject.coefficient
									]
								})] })]
							})
						}),
						MARK_FIELDS.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkCell, {
								label: t(field),
								value: row.marks[field],
								onCommit: (value) => {
									haptic(8);
									school.setStudentMark(row.subject.id, field, value).catch(() => school.flash(t("errorGeneric")));
								}
							})
						}, field)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 font-bold tabular-nums",
							children: row.average == null ? "—" : formatMark(school.settings.lang, row.average)
						})
					]
				}, row.subject.id)) })]
			})
		})
	] });
}
function MarkCell({ label, value, onCommit }) {
	const school = useSchool();
	const t = useT();
	const [text, setText] = (0, import_react.useState)(value == null ? "" : String(value));
	const [invalid, setInvalid] = (0, import_react.useState)(false);
	const [last, setLast] = (0, import_react.useState)(value);
	if (value !== last) {
		setLast(value);
		setText(value == null ? "" : String(value));
		setInvalid(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		dir: "ltr",
		inputMode: "decimal",
		"aria-label": label,
		"aria-invalid": invalid,
		value: text,
		onChange: (event) => {
			setText(event.target.value);
			setInvalid(false);
		},
		onBlur: () => {
			const parsed = parseMark(text);
			if (parsed === "invalid") {
				setInvalid(true);
				school.flash(t("invalidMark"));
				return;
			}
			if (parsed !== value) onCommit(parsed);
		},
		className: `${fieldClass} h-10 w-20 text-center tabular-nums ${invalid ? "border-danger" : ""}`
	});
}
function CalendarBoard() {
	const school = useSchool();
	useT();
	const now = /* @__PURE__ */ new Date();
	const [year, setYear] = (0, import_react.useState)(now.getFullYear());
	const [month, setMonth] = (0, import_react.useState)(now.getMonth());
	const [day, setDay] = (0, import_react.useState)(null);
	const firstDow = new Date(year, month, 1).getDay();
	const count = new Date(year, month + 1, 0).getDate();
	const cells = [...Array(firstDow).fill(null)];
	for (let d = 1; d <= count; d += 1) cells.push(d);
	while (cells.length % 7 !== 0) cells.push(null);
	const selectedIso = day == null ? null : isoDate(year, month, day);
	const selectedNote = school.notes.find((note) => note.date === selectedIso);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": String(year - 1),
					className: "press grid size-11 place-items-center rounded-full hover:bg-surface-2",
					onClick: () => setYear((value) => value - 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5 rtl:rotate-180" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg font-bold tabular-nums",
					children: year
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": String(year + 1),
					className: "press grid size-11 place-items-center rounded-full hover:bg-surface-2",
					onClick: () => setYear((value) => value + 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 rtl:rotate-180" })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 grid grid-cols-3 gap-2 sm:grid-cols-4",
			children: Array.from({ length: 12 }, (_, index) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						haptic(8);
						setMonth(index);
					},
					className: `press h-11 rounded-lg border text-sm font-semibold ${index === month ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"}`,
					children: monthName(school.settings.lang, index)
				}, index);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-xl border border-border bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-7 border-b border-border bg-surface-2 text-center text-xs font-semibold text-muted",
				children: Array.from({ length: 7 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-2",
					children: weekdayName(school.settings.lang, index + 1)
				}, index))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-7",
				children: cells.map((value, index) => {
					if (value == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-16 border-b border-e border-border" }, `e-${index}`);
					const iso = isoDate(year, month, value);
					const note = school.notes.find((item) => item.date === iso);
					const isToday = iso === isoDate(now.getFullYear(), now.getMonth(), now.getDate());
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							haptic(8);
							setDay(value);
						},
						className: "press min-h-16 border-b border-e border-border p-1.5 text-start hover:bg-surface-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `inline-grid size-7 place-items-center rounded-full text-sm font-semibold ${isToday ? "bg-primary text-primary-fg" : ""}`,
							children: value
						}), note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block truncate text-xs text-muted",
							children: note.note
						}) : null]
					}, iso);
				})
			})]
		}),
		selectedIso ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoteDialog, {
			iso: selectedIso,
			initial: selectedNote?.note ?? "",
			onClose: () => setDay(null)
		}) : null
	] });
}
function NoteDialog({ iso, initial, onClose }) {
	const school = useSchool();
	const t = useT();
	const [text, setText] = (0, import_react.useState)(initial);
	const save = async (next) => {
		try {
			await school.saveNote(iso, next);
			haptic(12);
			school.flash(t("saved"));
			onClose();
		} catch (error) {
			console.error(error);
			school.flash(t("errorGeneric"));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: formatDate(school.settings.lang, iso),
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: t("calendar"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "min-h-36 w-full rounded-lg border border-border bg-bg px-3 py-2 text-base text-fg",
				value: text,
				placeholder: t("notePlaceholder"),
				onChange: (event) => setText(event.target.value)
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: onClose,
					children: t("cancel")
				}),
				initial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					danger: true,
					onClick: () => void save(""),
					children: t("clearNote")
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => void save(text),
					children: t("save")
				})
			]
		})]
	});
}
function Grading() {
	const school = useSchool();
	const t = useT();
	const [sectionId, setSectionId] = (0, import_react.useState)(school.sections[0]?.id ?? null);
	const [termId, setTermId] = (0, import_react.useState)(school.terms[0]?.id ?? null);
	const [dialog, setDialog] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!school.sections.some((section) => section.id === sectionId)) setSectionId(school.sections[0]?.id ?? null);
	}, [school.sections, sectionId]);
	(0, import_react.useEffect)(() => {
		if (!school.terms.some((term) => term.id === termId)) setTermId(school.terms[0]?.id ?? null);
	}, [school.terms, termId]);
	const section = school.sections.find((item) => item.id === sectionId) ?? null;
	const term = school.terms.find((item) => item.id === termId) ?? null;
	const students = school.teacherGrades.filter((grade) => grade.section_id === sectionId && grade.term_id === termId).sort((a, b) => a.student_name.localeCompare(b.student_name, school.settings.lang));
	const exportSheet = async () => {
		if (!section || !term) return;
		const header = [
			t("studentName"),
			t("cc"),
			t("tp"),
			t("dev1"),
			t("dev2"),
			t("exam"),
			t("average")
		];
		const body = students.map((student) => {
			const avg = averageOf(student);
			return [
				student.student_name,
				student.cc,
				student.tp,
				student.dev1,
				student.dev2,
				student.exam,
				avg == null ? "" : formatMark(school.settings.lang, avg)
			];
		});
		const rows = [
			[t("sections"), section.name],
			[t("terms"), term.name],
			[],
			header,
			...body
		];
		const filename = `grades-${section.name}-${term.name}.csv`.replaceAll(/\s+/g, "-");
		try {
			const result = await shareCsv(filename, rows);
			if (result === "cancelled") return;
			haptic(12);
			school.flash(result === "shared" ? t("shared") : t("exported"));
		} catch (error) {
			console.error(error);
			school.flash(t("errorGeneric"));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Picker, {
				label: t("sections"),
				value: sectionId,
				options: school.sections.map((item) => ({
					id: item.id,
					name: item.name
				})),
				onChange: setSectionId,
				onAdd: () => setDialog({ type: "section" }),
				onDelete: () => setDialog({ type: "del-section" }),
				addLabel: t("addSection"),
				deleteLabel: t("deleteSection"),
				canDelete: sectionId != null
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Picker, {
				label: t("terms"),
				value: termId,
				options: school.terms.map((item) => ({
					id: item.id,
					name: item.name
				})),
				onChange: setTermId,
				onAdd: () => setDialog({ type: "term" }),
				onDelete: () => setDialog({ type: "del-term" }),
				addLabel: t("addTerm"),
				deleteLabel: t("deleteTerm"),
				canDelete: termId != null
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
				onClick: () => void exportSheet(),
				disabled: !section || !term || students.length === 0,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), t("exportExcel")]
			})
		}),
		!section || !term ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted",
			children: t("needSectionTerm")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-bold",
				children: t("students")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
				onClick: () => setDialog({ type: "student" }),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), t("addStudent")]
			})]
		}), students.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted",
			children: t("noStudents")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-2",
			children: students.map((student) => {
				const avg = averageOf(student);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						haptic(8);
						setDialog({
							type: "edit",
							id: student.id
						});
					},
					className: "press flex w-full items-center gap-3 rounded-xl border border-border bg-surface px-3 py-3 text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-full bg-surface-2 text-sm font-bold",
							children: student.student_name.slice(0, 1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-semibold",
								children: student.student_name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: t("editGrades")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: t("average")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-bold tabular-nums",
								children: avg == null ? "—" : formatMark(school.settings.lang, avg)
							})]
						})
					]
				}) }, student.id);
			})
		})] }),
		dialog?.type === "section" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameDialog, {
			title: t("addSection"),
			label: t("sectionName"),
			onClose: () => setDialog(null),
			onSave: async (name) => {
				await school.addSection(name);
				school.flash(t("saved"));
			}
		}) : null,
		dialog?.type === "term" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameDialog, {
			title: t("addTerm"),
			label: t("termName"),
			onClose: () => setDialog(null),
			onSave: async (name) => {
				await school.addTerm(name);
				school.flash(t("saved"));
			}
		}) : null,
		dialog?.type === "del-section" && section ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			title: t("deleteSection"),
			body: t("confirmDeleteSection"),
			onClose: () => setDialog(null),
			onConfirm: async () => {
				await school.deleteSection(section.id);
				school.flash(t("deleted"));
			}
		}) : null,
		dialog?.type === "del-term" && term ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			title: t("deleteTerm"),
			body: t("confirmDeleteTerm"),
			onClose: () => setDialog(null),
			onConfirm: async () => {
				await school.deleteTerm(term.id);
				school.flash(t("deleted"));
			}
		}) : null,
		dialog?.type === "student" && section && term ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameDialog, {
			title: t("addStudent"),
			label: t("studentName"),
			onClose: () => setDialog(null),
			onSave: async (name) => {
				await school.addTeacherStudent({
					sectionId: section.id,
					termId: term.id,
					name
				});
				school.flash(t("saved"));
			}
		}) : null,
		dialog?.type === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentEditor, {
			id: dialog.id,
			onClose: () => setDialog(null)
		}) : null
	] });
}
function Picker({ label, value, options, onChange, onAdd, onDelete, addLabel, deleteLabel, canDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mb-1 block text-sm font-medium",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: fieldClass,
				value: value ?? "",
				onChange: (event) => onChange(Number(event.target.value)),
				children: [options.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: label
				}) : null, options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: option.id,
					children: option.name
				}, option.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": addLabel,
				onClick: onAdd,
				className: "press grid size-11 shrink-0 place-items-center rounded-lg bg-primary text-primary-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": deleteLabel,
				disabled: !canDelete,
				onClick: onDelete,
				className: "press grid size-11 shrink-0 place-items-center rounded-lg border border-danger text-danger disabled:opacity-40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-5" })
			})
		]
	})] });
}
function NameDialog({ title, label, onClose, onSave }) {
	const school = useSchool();
	const t = useT();
	const [name, setName] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const submit = async () => {
		if (!name.trim()) {
			setError(t("required"));
			return;
		}
		try {
			await onSave(name);
			haptic(12);
			onClose();
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: onClose,
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => void submit(),
					children: t("save")
				})]
			})
		]
	});
}
function ConfirmDialog({ title, body, onClose, onConfirm }) {
	const school = useSchool();
	const t = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title,
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm",
			children: body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				onClick: onClose,
				children: t("cancel")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				danger: true,
				onClick: () => {
					onConfirm().then(() => {
						haptic(12);
						onClose();
					}).catch((error) => {
						console.error(error);
						school.flash(t("errorGeneric"));
					});
				},
				children: t("delete")
			})]
		})]
	});
}
function StudentEditor({ id, onClose }) {
	const school = useSchool();
	const t = useT();
	const row = school.teacherGrades.find((grade) => grade.id === id);
	const [name, setName] = (0, import_react.useState)(row?.student_name ?? "");
	const [texts, setTexts] = (0, import_react.useState)(() => ({
		cc: row?.cc == null ? "" : String(row.cc),
		tp: row?.tp == null ? "" : String(row.tp),
		dev1: row?.dev1 == null ? "" : String(row.dev1),
		dev2: row?.dev2 == null ? "" : String(row.dev2),
		exam: row?.exam == null ? "" : String(row.exam)
	}));
	const [error, setError] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	if (!row) return null;
	const draft = emptyMarks();
	let draftOk = true;
	for (const field of MARK_FIELDS) {
		const parsed = parseMark(texts[field]);
		if (parsed === "invalid") draftOk = false;
		else draft[field] = parsed;
	}
	const avg = draftOk ? averageOf({
		...row,
		...draft
	}) : null;
	const save = async () => {
		if (!name.trim()) {
			setError(t("required"));
			return;
		}
		const nextMarks = { ...emptyMarks() };
		for (const field of MARK_FIELDS) {
			const parsed = parseMark(texts[field]);
			if (parsed === "invalid") {
				setError(t("invalidMark"));
				return;
			}
			nextMarks[field] = parsed;
		}
		try {
			await school.updateTeacherGrade({
				...row,
				student_name: name.trim(),
				...nextMarks
			});
			haptic(12);
			school.flash(t("saved"));
			onClose();
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: t("editGrades"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("studentName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 grid grid-cols-2 gap-2",
				children: MARK_FIELDS.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t(field),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						dir: "ltr",
						inputMode: "decimal",
						className: fieldClass,
						value: texts[field],
						onChange: (event) => setTexts((current) => ({
							...current,
							[field]: event.target.value
						}))
					})
				}, field))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm",
				children: [
					t("average"),
					": ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold tabular-nums",
						children: avg == null ? "—" : formatMark(school.settings.lang, avg)
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-danger",
				children: error
			}) : null,
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm",
					children: t("confirmDeleteStudent")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: () => setConfirm(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						danger: true,
						onClick: () => {
							school.deleteTeacherGrade(row.id).then(() => {
								haptic(12);
								school.flash(t("deleted"));
								onClose();
							});
						},
						children: t("delete")
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: onClose,
						children: t("cancel")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						danger: true,
						onClick: () => setConfirm(true),
						children: t("deleteStudent")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => void save(),
						children: t("save")
					})
				]
			})
		]
	});
}
function placeDay(slots) {
	const sorted = [...slots].sort((a, b) => a.start_time.localeCompare(b.start_time) || a.end_time.localeCompare(b.end_time));
	const laneEnds = [];
	const placed = sorted.map((slot) => {
		const start = toMin(slot.start_time);
		const end = toMin(slot.end_time);
		let lane = laneEnds.findIndex((value) => value <= start);
		if (lane < 0) {
			lane = laneEnds.length;
			laneEnds.push(end);
		} else laneEnds[lane] = end;
		return {
			slot,
			lane,
			start,
			end
		};
	});
	const lanes = Math.max(1, laneEnds.length);
	return placed.map((item) => ({
		...item,
		lanes
	}));
}
function Timetable() {
	const school = useSchool();
	const t = useT();
	const scroller = (0, import_react.useRef)(null);
	const zoomRef = (0, import_react.useRef)(1);
	const [zoom, setZoom] = (0, import_react.useState)(1);
	zoomRef.current = zoom;
	const [adding, setAdding] = (0, import_react.useState)(null);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("menu");
	const [preview, setPreview] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		let pinch = null;
		const distance = (touches) => {
			const dx = touches[0].clientX - touches[1].clientX;
			const dy = touches[0].clientY - touches[1].clientY;
			return Math.hypot(dx, dy);
		};
		const start = (event) => {
			if (event.touches.length === 2) pinch = {
				dist: distance(event.touches),
				zoom: zoomRef.current
			};
		};
		const move = (event) => {
			if (event.touches.length === 2 && pinch) {
				event.preventDefault();
				setZoom(clampZoom(pinch.zoom * (distance(event.touches) / pinch.dist)));
			}
		};
		const end = () => {
			pinch = null;
		};
		const wheel = (event) => {
			if (!event.ctrlKey) return;
			event.preventDefault();
			setZoom((value) => clampZoom(value * (event.deltaY > 0 ? .96 : 1.04)));
		};
		el.addEventListener("touchstart", start, { passive: true });
		el.addEventListener("touchmove", move, { passive: false });
		el.addEventListener("touchend", end);
		el.addEventListener("wheel", wheel, { passive: false });
		return () => {
			el.removeEventListener("touchstart", start);
			el.removeEventListener("touchmove", move);
			el.removeEventListener("touchend", end);
			el.removeEventListener("wheel", wheel);
		};
	}, []);
	const colW = Math.round(78 * zoom);
	const rowH = Math.round(48 * zoom);
	const railW = 56;
	const boardW = railW + colW * 7;
	const boardH = rowH * 13;
	const todayDow = (/* @__PURE__ */ new Date()).getDay() + 1;
	const hours = hourLabels();
	const times = timeOptions();
	const openTasks = school.tasks.filter((task) => !task.is_completed).sort((a, b) => a.due_date.localeCompare(b.due_date));
	const subjectOf = (id) => school.subjects.find((subject) => subject.id === id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: t("fromTo")
			}), school.slots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("noClassesHint")
			}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
						label: t("zoomOut"),
						onClick: () => {
							haptic(8);
							setZoom((value) => clampZoom(value - .1));
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-label": t("zoomReset"),
						onClick: () => {
							haptic(8);
							setZoom(1);
						},
						className: "press min-h-11 min-w-14 rounded-full text-sm font-bold tabular-nums",
						children: [Math.round(zoom * 100), "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
						label: t("zoomIn"),
						onClick: () => {
							haptic(8);
							setZoom((value) => clampZoom(value + .1));
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-5" })
					})
				]
			})]
		}),
		openTasks.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 text-xs font-semibold text-muted",
				children: t("upcoming")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: openTasks.map((task) => {
					const subject = subjectOf(task.subject_id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-w-44 shrink-0 items-start gap-2 rounded-xl border border-border bg-surface px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-1 size-4 accent-primary",
							"aria-label": t("markDone"),
							onChange: () => {
								haptic(10);
								school.toggleTask(task.id, true);
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-semibold",
								children: task.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate text-xs text-muted",
								children: [
									subject?.name ?? "",
									" · ",
									formatDate(school.settings.lang, task.due_date)
								]
							})]
						})]
					}, task.id);
				})
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
				onClick: () => {
					haptic(10);
					setAdding({
						day: todayDow,
						start: "08:00"
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), t("addClass")]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			className: "board-scroll overflow-auto rounded-xl border border-border bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { width: boardW },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky top-0 z-20 flex border-b border-border bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "shrink-0",
						style: { width: railW }
					}), Array.from({ length: 7 }, (_, index) => {
						const day = index + 1;
						const today = day === todayDow;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: { width: colW },
							className: `shrink-0 border-s border-border px-1 py-2 text-center text-xs font-bold ${today ? "text-primary" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: weekdayName(school.settings.lang, day) }), today ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: t("today")
							}) : null]
						}, day);
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex",
					style: { height: boardH },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky start-0 z-10 shrink-0 border-e border-border bg-surface",
						style: { width: railW },
						children: hours.map((hour, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0 px-1 text-xs text-muted tabular-nums",
							style: { top: index * rowH + 2 },
							children: toHHMM(hour * 60)
						}, hour))
					}), Array.from({ length: 7 }, (_, index) => {
						const day = index + 1;
						const placed = placeDay(school.slots.filter((slot) => slot.day_of_week === day));
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `isolate relative shrink-0 border-s border-border ${day === todayDow ? "today-col" : ""}`,
							style: {
								width: colW,
								height: boardH
							},
							children: [hours.map((hour, hourIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "absolute inset-x-0 border-b border-border hover:bg-surface-2",
								style: {
									top: hourIndex * rowH,
									height: rowH
								},
								"aria-label": `${t("addClass")} ${weekdayName(school.settings.lang, day, "long")} ${toHHMM(hour * 60)}`,
								onClick: () => {
									haptic(8);
									setAdding({
										day,
										start: toHHMM(hour * 60)
									});
								}
							}, hour)), placed.map((item) => {
								const subject = subjectOf(item.slot.subject_id);
								if (!subject) return null;
								const span = DAY_END - 480;
								const start = Math.max(item.start, 480);
								const end = Math.min(Math.max(item.end, start + 30), DAY_END);
								const top = (start - 480) / span * 100;
								const height = (end - start) / span * 100;
								const hasTask = school.tasks.some((task) => task.subject_id === subject.id && !task.is_completed);
								const hasFile = school.attachments.some((file) => file.subject_id === subject.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "absolute z-10 overflow-hidden rounded-md px-1 py-0.5 text-start",
									style: {
										top: `calc(${top}% + 2px)`,
										height: `calc(${height}% - 4px)`,
										width: `calc(${100 / item.lanes}% - 4px)`,
										insetInlineStart: `calc(${item.lane * 100 / item.lanes}% + 2px)`,
										background: subject.color,
										color: foregroundFor(subject.color)
									},
									onClick: () => {
										haptic(10);
										setMode("menu");
										setOpenId(item.slot.id);
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-xs font-bold",
											children: subject.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-xs",
											children: subject.teacher
										}),
										(hasTask || hasFile) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-0.5 flex gap-1",
											children: [hasTask ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
												className: "size-3",
												"aria-hidden": "true"
											}) : null, hasFile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, {
												className: "size-3",
												"aria-hidden": "true"
											}) : null]
										})
									]
								}, item.slot.id);
							})]
						}, day);
					})]
				})]
			})
		}),
		adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddClassDialog, {
			day: adding.day,
			start: adding.start,
			times,
			onClose: () => setAdding(null)
		}) : null,
		openId != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClassDialog, {
			slotId: openId,
			mode,
			setMode,
			onClose: () => setOpenId(null),
			onPreview: setPreview
		}) : null,
		preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePreview, {
			preview,
			onClose: () => setPreview(null)
		}) : null
	] });
}
function AddClassDialog({ day, start, times, onClose }) {
	const school = useSchool();
	const t = useT();
	const [dayValue, setDayValue] = (0, import_react.useState)(day);
	const [name, setName] = (0, import_react.useState)("");
	const [teacher, setTeacher] = (0, import_react.useState)("");
	const [color, setColor] = (0, import_react.useState)(SUBJECT_COLORS[0]);
	const [coef, setCoef] = (0, import_react.useState)("1");
	const [startValue, setStartValue] = (0, import_react.useState)(start);
	const [endValue, setEndValue] = (0, import_react.useState)(toHHMM(Math.min(toMin(start) + 60, DAY_END)));
	const [error, setError] = (0, import_react.useState)("");
	const [listOpen, setListOpen] = (0, import_react.useState)(false);
	const suggestions = (0, import_react.useMemo)(() => {
		const query = name.trim().toLowerCase();
		if (!query) return school.subjects.slice(0, 6);
		return school.subjects.filter((subject) => subject.name.toLowerCase().includes(query)).slice(0, 6);
	}, [name, school.subjects]);
	const matched = school.subjects.find((subject) => subject.name.trim().toLowerCase() === name.trim().toLowerCase());
	const submit = async () => {
		const coefficient = Number(coef.replace(",", "."));
		if (!name.trim() || !teacher.trim() || !Number.isFinite(coefficient) || coefficient <= 0) {
			setError(t("required"));
			return;
		}
		if (toMin(endValue) <= toMin(startValue)) {
			setError(t("timeOrder"));
			return;
		}
		try {
			await school.saveClass({
				name,
				teacher,
				color,
				coefficient,
				day: dayValue,
				start: startValue,
				end: endValue
			});
			haptic(16);
			school.flash(t("classSaved"));
			onClose();
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: t("addClass"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("day"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: fieldClass,
					value: dayValue,
					onChange: (event) => setDayValue(Number(event.target.value)),
					children: Array.from({ length: 7 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: index + 1,
						children: weekdayName(school.settings.lang, index + 1, "long")
					}, index + 1))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: t("subject"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: name,
					autoComplete: "off",
					onChange: (event) => {
						setName(event.target.value);
						setListOpen(true);
					},
					onFocus: () => setListOpen(true)
				}), listOpen && suggestions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1 overflow-hidden rounded-lg border border-border bg-bg",
					children: suggestions.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-2 px-3 py-2 text-start text-sm hover:bg-surface-2",
						onClick: () => {
							setName(subject.name);
							setTeacher(subject.teacher);
							setColor(subject.color);
							setCoef(String(subject.coefficient));
							setListOpen(false);
							haptic(8);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-3 rounded-full",
								style: { background: subject.color }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: subject.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-muted",
								children: subject.teacher
							})
						]
					}) }, subject.id))
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("teacherName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: teacher,
					onChange: (event) => setTeacher(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t("start"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						dir: "ltr",
						className: fieldClass,
						value: startValue,
						onChange: (event) => setStartValue(event.target.value),
						children: times.map((time) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: time }, time))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t("end"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						dir: "ltr",
						className: fieldClass,
						value: endValue,
						onChange: (event) => setEndValue(event.target.value),
						children: times.map((time) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: time }, time))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("coefficient"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					dir: "ltr",
					inputMode: "decimal",
					className: fieldClass,
					value: coef,
					onChange: (event) => setCoef(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-1 text-sm font-medium",
						children: t("color")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: SUBJECT_COLORS.map((swatch) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": swatch,
							"aria-pressed": color === swatch,
							onClick: () => setColor(swatch),
							className: "size-11 rounded-full border-2",
							style: {
								background: swatch,
								borderColor: color === swatch ? "var(--fg)" : "transparent"
							}
						}, swatch))
					}),
					matched ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: t("colorShared")
					}) : null
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: onClose,
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => void submit(),
					children: t("save")
				})]
			})
		]
	});
}
function ClassDialog({ slotId, mode, setMode, onClose, onPreview }) {
	const school = useSchool();
	const t = useT();
	const slot = school.slots.find((item) => item.id === slotId);
	const subject = school.subjects.find((item) => item.id === slot?.subject_id);
	const [title, setTitle] = (0, import_react.useState)("");
	const [due, setDue] = (0, import_react.useState)(tomorrowIso());
	const [fileTitle, setFileTitle] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const imageRef = (0, import_react.useRef)(null);
	const pdfRef = (0, import_react.useRef)(null);
	if (!slot || !subject) return null;
	const tasks = school.tasks.filter((task) => task.subject_id === subject.id);
	const files = school.attachments.filter((item) => item.subject_id === subject.id);
	const saveTask = async () => {
		if (!title.trim() || !due) {
			setError(t("required"));
			return;
		}
		try {
			const permitted = await school.addTask({
				subjectId: subject.id,
				title,
				due
			});
			haptic(16);
			school.flash(permitted ? t("reminderSet") : t("reminderOff"));
			setTitle("");
			setMode("menu");
			setError("");
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	const saveFile = async () => {
		if (!fileTitle.trim() || !file) {
			setError(!file ? t("chooseFile") : t("required"));
			return;
		}
		const type = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf") ? "pdf" : "image";
		try {
			await school.addAttachment({
				subjectId: subject.id,
				title: fileTitle,
				type,
				file,
				filename: file.name
			});
			haptic(16);
			school.flash(t("saved"));
			setFile(null);
			setFileTitle("");
			setMode("menu");
			setError("");
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	const removeClass = async () => {
		try {
			await school.deleteSlot(slot.id);
			haptic(16);
			school.flash(t("deleted"));
			onClose();
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	const openFile = (item) => {
		onPreview({
			url: URL.createObjectURL(item.blob),
			title: item.title,
			type: item.type,
			filename: item.file_path
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: subject.name,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 text-sm text-muted",
				children: subject.teacher
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-4 text-sm font-semibold tabular-nums",
				dir: "ltr",
				children: [
					weekdayName(school.settings.lang, slot.day_of_week, "long"),
					" · ",
					slot.start_time,
					"–",
					slot.end_time
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-4 text-xs text-muted",
				children: [
					t("coefShort"),
					" ",
					subject.coefficient
				]
			}),
			mode === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GhostButton, {
						onClick: () => {
							setError("");
							setMode("task");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }),
							" ",
							t("addTask")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GhostButton, {
						onClick: () => {
							setError("");
							setMode("file");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4" }),
							" ",
							t("addFile")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GhostButton, {
						danger: true,
						onClick: () => setMode("confirm"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }),
							" ",
							t("deleteClass")
						]
					})
				]
			}) : null,
			mode === "task" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("taskTitle"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: title,
							onChange: (event) => setTitle(event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("dueDate"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							dir: "ltr",
							type: "date",
							className: fieldClass,
							value: due,
							onChange: (event) => setDue(event.target.value)
						})
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							onClick: () => setMode("menu"),
							children: t("back")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: () => void saveTask(),
							children: t("save")
						})]
					})
				]
			}) : null,
			mode === "file" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("fileTitle"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: fileTitle,
							onChange: (event) => setFileTitle(event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: imageRef,
						hidden: true,
						type: "file",
						accept: "image/*",
						onChange: (event) => {
							const picked = event.target.files?.[0];
							if (!picked) return;
							setFile(picked);
							if (!fileTitle.trim()) setFileTitle(picked.name.replace(/\.[^.]+$/, ""));
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: pdfRef,
						hidden: true,
						type: "file",
						accept: "application/pdf",
						onChange: (event) => {
							const picked = event.target.files?.[0];
							if (!picked) return;
							setFile(picked);
							if (!fileTitle.trim()) setFileTitle(picked.name.replace(/\.[^.]+$/, ""));
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							onClick: () => imageRef.current?.click(),
							children: t("pickImage")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							onClick: () => pdfRef.current?.click(),
							children: t("pickPdf")
						})]
					}),
					file ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 truncate text-sm text-muted",
						children: file.name
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							onClick: () => setMode("menu"),
							children: t("back")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: () => void saveFile(),
							children: t("save")
						})]
					})
				]
			}) : null,
			mode === "confirm" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm",
					children: t("confirmDeleteClass")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: () => setMode("menu"),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						danger: true,
						onClick: () => void removeClass(),
						children: t("delete")
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm font-bold",
				children: t("tasks")
			}),
			tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted",
				children: t("noTasks")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mb-4 grid gap-2",
				children: tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-lg border border-border px-2 py-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": task.is_completed ? t("markOpen") : t("markDone"),
							className: "grid size-11 place-items-center",
							onClick: () => {
								haptic(8);
								school.toggleTask(task.id, !task.is_completed);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: `size-4 ${task.is_completed ? "text-ok" : "text-muted"}` })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `min-w-0 flex-1 ${task.is_completed ? "text-muted line-through" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-medium",
								children: task.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: formatDate(school.settings.lang, task.due_date)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t("delete"),
							className: "grid size-11 place-items-center text-danger",
							onClick: () => void school.deleteTask(task.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				}, task.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm font-bold",
				children: t("files")
			}),
			files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("noFiles")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2",
				children: files.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-lg border border-border px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-w-0 flex-1 text-start",
						onClick: () => openFile(item),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-medium",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs text-muted",
							children: [
								item.type === "pdf" ? t("pdf") : t("image"),
								" · ",
								t("uploadDate"),
								" ",
								formatDate(school.settings.lang, item.upload_date)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": t("delete"),
						className: "grid size-11 place-items-center text-danger",
						onClick: () => void school.deleteAttachment(item.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				}, item.id))
			})
		]
	});
}
function FilePreview({ preview, onClose }) {
	const t = useT();
	(0, import_react.useEffect)(() => () => URL.revokeObjectURL(preview.url), [preview.url]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: preview.title,
		onClose,
		children: [preview.type === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: preview.url,
			alt: preview.title,
			className: "mb-3 max-h-[60dvh] w-full rounded-lg object-contain"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			title: preview.title,
			src: preview.url,
			className: "mb-3 h-[60dvh] w-full rounded-lg border border-border"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "press inline-flex h-11 items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg",
			href: preview.url,
			download: preview.filename,
			children: t("download")
		})]
	});
}
function Tutoring() {
	const school = useSchool();
	const t = useT();
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const rows = [...school.tutoring].sort((a, b) => a.name.localeCompare(b.name, school.settings.lang));
	const billed = rows.reduce((sum, row) => sum + row.total_amount, 0);
	const collected = rows.reduce((sum, row) => sum + row.paid_amount, 0);
	const outstanding = billed - collected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-muted",
			children: t("tutoringHint")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mb-4 grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t("billed"),
					value: formatMoney(school.settings.lang, billed)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t("collected"),
					value: formatMoney(school.settings.lang, collected)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t("outstanding"),
					value: formatMoney(school.settings.lang, outstanding),
					tone: outstanding > .009 ? "due" : "ok"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
				onClick: () => {
					haptic(8);
					setAdding(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), t("addTutoring")]
			})
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted",
			children: t("noTutoring")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-2",
			children: rows.map((row) => {
				const remaining = row.total_amount - row.paid_amount;
				const ratio = row.total_amount > 0 ? Math.min(1, row.paid_amount / row.total_amount) : row.paid_amount > 0 ? 1 : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						haptic(8);
						setEditId(row.id);
					},
					className: "press w-full rounded-xl border border-border bg-surface p-3 text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-semibold",
									children: row.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate text-sm text-muted",
									children: [
										row.group_name,
										" · ",
										row.location
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-end",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted",
										children: t("remaining")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `block text-lg font-bold tabular-nums ${remaining > .009 ? "text-danger" : "text-ok"}`,
										children: formatMoney(school.settings.lang, remaining)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-xs font-semibold ${remaining > .009 ? "text-danger" : "text-ok"}`,
										children: remaining > .009 ? t("dueBalance") : t("settled")
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-3 grid grid-cols-2 gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-lg bg-surface-2 px-2 py-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: t("total")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold tabular-nums",
									children: formatMoney(school.settings.lang, row.total_amount)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-lg bg-surface-2 px-2 py-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: t("paid")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold tabular-nums",
									children: formatMoney(school.settings.lang, row.paid_amount)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-3 block h-1.5 overflow-hidden rounded-full bg-surface-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block h-full bg-primary",
								style: { width: `${ratio * 100}%` }
							})
						})
					]
				}) }, row.id);
			})
		}),
		adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddTutoring, { onClose: () => setAdding(false) }) : null,
		editId != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditTutoring, {
			id: editId,
			onClose: () => setEditId(null)
		}) : null
	] });
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-surface px-2 py-3 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-1 text-sm font-bold tabular-nums ${tone === "due" ? "text-danger" : tone === "ok" ? "text-ok" : ""}`,
			children: value
		})]
	});
}
function AddTutoring({ onClose }) {
	const school = useSchool();
	const t = useT();
	const [name, setName] = (0, import_react.useState)("");
	const [group, setGroup] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [total, setTotal] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const save = async () => {
		const amount = parseAmount(total);
		if (!name.trim() || !group.trim() || !location.trim()) {
			setError(t("required"));
			return;
		}
		if (amount === "invalid") {
			setError(t("amountInvalid"));
			return;
		}
		try {
			await school.addTutoring({
				name: name.trim(),
				group_name: group.trim(),
				location: location.trim(),
				total_amount: amount
			});
			haptic(12);
			school.flash(t("saved"));
			onClose();
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: t("addTutoring"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("studentName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: name,
					onChange: (event) => setName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("group"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: group,
					onChange: (event) => setGroup(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("location"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: location,
					onChange: (event) => setLocation(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("total"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					dir: "ltr",
					inputMode: "decimal",
					className: fieldClass,
					value: total,
					onChange: (event) => setTotal(event.target.value)
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: onClose,
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => void save(),
					children: t("save")
				})]
			})
		]
	});
}
function EditTutoring({ id, onClose }) {
	const school = useSchool();
	const t = useT();
	const row = school.tutoring.find((student) => student.id === id);
	const [draft, setDraft] = (0, import_react.useState)(row ?? null);
	const [paid, setPaid] = (0, import_react.useState)(row ? String(row.paid_amount) : "");
	const [total, setTotal] = (0, import_react.useState)(row ? String(row.total_amount) : "");
	const [error, setError] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	if (!row || !draft) return null;
	const paidValue = parseAmount(paid);
	const totalValue = parseAmount(total);
	const remaining = paidValue !== "invalid" && totalValue !== "invalid" ? totalValue - paidValue : row.total_amount - row.paid_amount;
	const save = async () => {
		if (!draft.name.trim() || !draft.group_name.trim() || !draft.location.trim()) {
			setError(t("required"));
			return;
		}
		if (paidValue === "invalid" || totalValue === "invalid") {
			setError(t("amountInvalid"));
			return;
		}
		try {
			await school.updateTutoring({
				...draft,
				name: draft.name.trim(),
				group_name: draft.group_name.trim(),
				location: draft.location.trim(),
				paid_amount: paidValue,
				total_amount: totalValue
			});
			haptic(12);
			school.flash(t("saved"));
			onClose();
		} catch (err) {
			console.error(err);
			school.flash(t("errorGeneric"));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: t("updatePaid"),
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("studentName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: draft.name,
					onChange: (event) => setDraft({
						...draft,
						name: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("group"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: draft.group_name,
					onChange: (event) => setDraft({
						...draft,
						group_name: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("location"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: draft.location,
					onChange: (event) => setDraft({
						...draft,
						location: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("total"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					dir: "ltr",
					inputMode: "decimal",
					className: fieldClass,
					value: total,
					onChange: (event) => setTotal(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: t("paid"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					dir: "ltr",
					inputMode: "decimal",
					className: fieldClass,
					value: paid,
					onChange: (event) => setPaid(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: `mb-3 text-sm font-semibold ${remaining > .009 ? "text-danger" : "text-ok"}`,
				children: [
					t("remaining"),
					": ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatMoney(school.settings.lang, remaining)
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-danger",
				children: error
			}) : null,
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					onClick: () => setConfirm(false),
					children: t("cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					danger: true,
					onClick: () => {
						school.deleteTutoring(row.id).then(() => {
							haptic(12);
							school.flash(t("deleted"));
							onClose();
						});
					},
					children: t("delete")
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: onClose,
						children: t("cancel")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						danger: true,
						onClick: () => setConfirm(true),
						children: t("deleteStudent")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => void save(),
						children: t("save")
					})
				]
			})
		]
	});
}
function SchoolApp() {
	const school = useSchool();
	const t = useT();
	if (!school.ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-bg px-6 text-center text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "mx-auto size-14 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-lg font-bold",
				children: "School Manager"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "مدير المدرسة"
			})
		] })
	});
	if (school.bootError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-bg px-6 text-center text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-bold",
			children: t("bootError")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: t("bootErrorAlt")
		})] })
	});
	if (!school.settings.activated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activate, {});
	if (!school.settings.role) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleSelect, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
function Activate() {
	const school = useSchool();
	const t = useT();
	const [key, setKey] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(false);
	const submit = async () => {
		try {
			if (!await school.activate(key)) {
				setError(true);
				haptic(20);
				return;
			}
			haptic(16);
		} catch (err) {
			console.error(err);
			setError(true);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center bg-bg px-5 py-8 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopToggles, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-2xl border border-border bg-surface p-6 shadow-lift",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-12 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs font-semibold tracking-wide text-accent",
					children: t("appNameAlt")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-extrabold leading-tight",
					children: t("appName")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t("tagline")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-6 text-lg font-bold",
					children: t("activateTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: t("activateHint")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-sm font-medium",
						children: t("licenseLabel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						dir: "ltr",
						autoCapitalize: "characters",
						autoComplete: "off",
						spellCheck: false,
						value: key,
						placeholder: t("licensePlaceholder"),
						onChange: (event) => {
							setKey(event.target.value);
							setError(false);
						},
						className: `${fieldClass} text-center tracking-widest ${error ? "border-danger" : ""}`
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: t("invalidLicense")
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => void submit(),
						children: t("activate")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted",
					dir: "ltr",
					children: t("devKey")
				})
			]
		})]
	});
}
function RoleSelect() {
	const school = useSchool();
	const t = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col bg-bg px-5 py-6 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopToggles, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-8 w-full max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-12 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-3xl font-extrabold",
					children: t("roleTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t("roleHint")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							haptic(12);
							school.setRole("student");
						},
						className: "press rounded-2xl border border-border bg-surface p-5 text-start hover:border-primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-8 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-4 block text-xl font-bold",
								children: t("student")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm text-muted",
								children: t("studentBlurb")
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							haptic(12);
							school.setRole("teacher");
						},
						className: "press rounded-2xl border border-border bg-surface p-5 text-start hover:border-primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-8 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-4 block text-xl font-bold",
								children: t("teacher")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm text-muted",
								children: t("teacherBlurb")
							})
						]
					})]
				})
			]
		})]
	});
}
function Shell() {
	const school = useSchool();
	const t = useT();
	const [tab, setTab] = (0, import_react.useState)("timetable");
	const [switching, setSwitching] = (0, import_react.useState)(false);
	const role = school.settings.role;
	(0, import_react.useEffect)(() => {
		setTab("timetable");
	}, [role]);
	const tabs = role === "teacher" ? [
		{
			id: "timetable",
			label: t("timetable"),
			icon: LayoutGrid
		},
		{
			id: "grading",
			label: t("grading"),
			icon: Table2
		},
		{
			id: "tutoring",
			label: t("tutoring"),
			icon: Wallet
		}
	] : [
		{
			id: "timetable",
			label: t("timetable"),
			icon: LayoutGrid
		},
		{
			id: "averages",
			label: t("averages"),
			icon: Table2
		},
		{
			id: "calendar",
			label: t("calendar"),
			icon: CalendarDays
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center gap-1 border-b border-border bg-bg/90 px-2 py-1 backdrop-blur-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 shrink-0 place-items-center rounded-lg bg-primary text-primary-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 px-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-bold leading-tight",
							children: t("appName")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted",
							children: role === "teacher" ? t("roleTeacher") : t("roleStudent")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopToggles, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": t("switchRole"),
						onClick: () => setSwitching(true),
						className: "press grid size-11 place-items-center rounded-full hover:bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto w-full max-w-5xl px-3 pt-4 pb-28",
				children: [
					tab === "timetable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timetable, {}) : null,
					tab === "averages" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Averages, {}) : null,
					tab === "calendar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarBoard, {}) : null,
					tab === "grading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grading, {}) : null,
					tab === "tutoring" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tutoring, {}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-3",
					children: tabs.map((item) => {
						const Icon = item.icon;
						const active = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-current": active ? "page" : void 0,
							onClick: () => {
								haptic(8);
								setTab(item.id);
							},
							className: `press flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-semibold ${active ? "text-primary" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
						}, item.id);
					})
				})
			}),
			school.toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-fg px-4 py-2 text-sm font-medium text-bg shadow-lift",
					children: school.toast
				})
			}) : null,
			switching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				title: t("switchRoleTitle"),
				onClose: () => setSwitching(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm",
					children: t("switchRoleBody")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: () => setSwitching(false),
						children: t("cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => {
							const next = role === "teacher" ? "student" : "teacher";
							school.setRole(next);
							haptic(12);
							setSwitching(false);
						},
						children: role === "teacher" ? t("student") : t("teacher")
					})]
				})]
			}) : null
		]
	});
}
function TopToggles() {
	const school = useSchool();
	const t = useT();
	const dark = school.settings.theme === "dark";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": t("language"),
			onClick: () => {
				haptic(8);
				school.setLang(school.settings.lang === "ar" ? "en" : "ar");
			},
			className: "press grid h-11 min-w-11 place-items-center rounded-full px-2 text-sm font-bold hover:bg-surface-2",
			children: school.settings.lang === "ar" ? "EN" : "ع"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": dark ? t("lightMode") : t("darkMode"),
			onClick: () => {
				haptic(8);
				school.setTheme(dark ? "light" : "dark");
			},
			className: "press grid size-11 place-items-center rounded-full hover:bg-surface-2",
			children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchoolProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchoolApp, {}) });
}
//#endregion
export { Home as component };
