import { useState } from "react";
import { fieldClass } from "@/components/school/ui";
import { formatMark, haptic, parseMark } from "@/lib/school/format";
import { averageOf, generalAverage } from "@/lib/school/grades";
import { useSchool, useT } from "@/lib/school/store";
import { MARK_FIELDS, type Marks } from "@/lib/school/types";

export function Averages() {
  const school = useSchool();
  const t = useT();
  const orderedIds: number[] = [];
  const slots = [...school.slots].sort(
    (a, b) => a.day_of_week - b.day_of_week || a.start_time.localeCompare(b.start_time),
  );
  for (const slot of slots) {
    if (!orderedIds.includes(slot.subject_id)) orderedIds.push(slot.subject_id);
  }
  const rows = orderedIds
    .map((id) => school.subjects.find((subject) => subject.id === id))
    .filter((subject) => subject != null)
    .map((subject) => {
      const grade = school.grades.find((item) => item.subject_id === subject.id);
      const marks: Marks = {
        cc: grade?.cc ?? null,
        tp: grade?.tp ?? null,
        dev1: grade?.dev1 ?? null,
        dev2: grade?.dev2 ?? null,
        exam: grade?.exam ?? null,
      };
      return { subject, marks, average: averageOf(marks) };
    });
  const overall = generalAverage(rows.map((row) => ({ average: row.average, coefficient: row.subject.coefficient })));

  return (
    <div>
      <section className="ledger-card mb-4 rounded-2xl p-5">
        <p className="text-sm font-medium">{t("generalAverage")}</p>
        <p className="mt-1 text-4xl font-extrabold tabular-nums">
          {overall == null ? "—" : formatMark(school.settings.lang, overall)}
        </p>
        <p className="text-sm opacity-80">{t("outOf")}</p>
      </section>
      <p className="mb-4 text-sm text-muted">{t("averagesHint")}</p>
      {rows.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted">{t("noSubjects")}</p>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-border">
          <table className="w-full min-w-[760px] border-collapse text-sm">
            <thead className="bg-surface-2 text-start">
              <tr>
                <th className="sticky start-0 z-10 bg-surface-2 px-3 py-2 text-start font-semibold">{t("subject")}</th>
                {[t("cc"), t("tp"), t("dev1"), t("dev2"), t("exam"), t("average")].map((label) => (
                  <th key={label} className="px-3 py-2 text-start font-semibold">
                    {label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.subject.id} className="border-t border-border">
                  <th className="sticky start-0 z-10 bg-surface px-3 py-2 text-start font-semibold">
                    <span className="flex items-center gap-2">
                      <span className="size-2.5 rounded-full" style={{ background: row.subject.color }} />
                      <span>
                        {row.subject.name}
                        <span className="block text-xs font-normal text-muted">
                          {t("coefShort")} {row.subject.coefficient}
                        </span>
                      </span>
                    </span>
                  </th>
                  {MARK_FIELDS.map((field) => (
                    <td key={field} className="px-2 py-2">
                      <MarkCell
                        label={t(field)}
                        value={row.marks[field]}
                        onCommit={(value) => {
                          haptic(8);
                          void school.setStudentMark(row.subject.id, field, value).catch(() => school.flash(t("errorGeneric")));
                        }}
                      />
                    </td>
                  ))}
                  <td className="px-3 py-2 font-bold tabular-nums">
                    {row.average == null ? "—" : formatMark(school.settings.lang, row.average)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function MarkCell({
  label,
  value,
  onCommit,
}: {
  label: string;
  value: number | null;
  onCommit: (value: number | null) => void;
}) {
  const school = useSchool();
  const t = useT();
  const [text, setText] = useState(value == null ? "" : String(value));
  const [invalid, setInvalid] = useState(false);
  const [last, setLast] = useState(value);

  if (value !== last) {
    setLast(value);
    setText(value == null ? "" : String(value));
    setInvalid(false);
  }

  return (
    <input
      dir="ltr"
      inputMode="decimal"
      aria-label={label}
      aria-invalid={invalid}
      value={text}
      onChange={(event) => {
        setText(event.target.value);
        setInvalid(false);
      }}
      onBlur={() => {
        const parsed = parseMark(text);
        if (parsed === "invalid") {
          setInvalid(true);
          school.flash(t("invalidMark"));
          return;
        }
        if (parsed !== value) onCommit(parsed);
      }}
      className={`${fieldClass} h-10 w-20 text-center tabular-nums ${invalid ? "border-danger" : ""}`}
    />
  );
}
