import { Bell, Check, Paperclip, Plus, Trash2, ZoomIn, ZoomOut } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Field, GhostButton, IconButton, Modal, PrimaryButton, fieldClass } from "@/components/school/ui";
import {
  DAY_END,
  DAY_START,
  SLOT_COUNT,
  SUBJECT_COLORS,
  clampZoom,
  foregroundFor,
  formatDate,
  haptic,
  hourLabels,
  timeOptions,
  toHHMM,
  toMin,
  tomorrowIso,
  weekdayName,
} from "@/lib/school/format";
import { useSchool, useT } from "@/lib/school/store";
import type { Attachment, ClassSlot } from "@/lib/school/types";

type AddState = { day: number; start: string };
type Preview = { url: string; title: string; type: "image" | "pdf"; filename: string };

function placeDay(slots: ClassSlot[]) {
  const sorted = [...slots].sort(
    (a, b) => a.start_time.localeCompare(b.start_time) || a.end_time.localeCompare(b.end_time),
  );
  const laneEnds: number[] = [];
  const placed = sorted.map((slot) => {
    const start = toMin(slot.start_time);
    const end = toMin(slot.end_time);
    let lane = laneEnds.findIndex((value) => value <= start);
    if (lane < 0) {
      lane = laneEnds.length;
      laneEnds.push(end);
    } else {
      laneEnds[lane] = end;
    }
    return { slot, lane, start, end };
  });
  const lanes = Math.max(1, laneEnds.length);
  return placed.map((item) => ({ ...item, lanes }));
}

export function Timetable() {
  const school = useSchool();
  const t = useT();
  const scroller = useRef<HTMLDivElement>(null);
  const zoomRef = useRef(1);
  const [zoom, setZoom] = useState(1);
  zoomRef.current = zoom;
  const [adding, setAdding] = useState<AddState | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const [mode, setMode] = useState<"menu" | "task" | "file" | "confirm">("menu");
  const [preview, setPreview] = useState<Preview | null>(null);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    let pinch: { dist: number; zoom: number } | null = null;
    const distance = (touches: TouchList) => {
      const dx = touches[0].clientX - touches[1].clientX;
      const dy = touches[0].clientY - touches[1].clientY;
      return Math.hypot(dx, dy);
    };
    const start = (event: TouchEvent) => {
      if (event.touches.length === 2) pinch = { dist: distance(event.touches), zoom: zoomRef.current };
    };
    const move = (event: TouchEvent) => {
      if (event.touches.length === 2 && pinch) {
        event.preventDefault();
        setZoom(clampZoom(pinch.zoom * (distance(event.touches) / pinch.dist)));
      }
    };
    const end = () => {
      pinch = null;
    };
    const wheel = (event: WheelEvent) => {
      if (!event.ctrlKey) return;
      event.preventDefault();
      setZoom((value) => clampZoom(value * (event.deltaY > 0 ? 0.96 : 1.04)));
    };
    el.addEventListener("touchstart", start, { passive: true });
    el.addEventListener("touchmove", move, { passive: false });
    el.addEventListener("touchend", end);
    el.addEventListener("wheel", wheel, { passive: false });
    return () => {
      el.removeEventListener("touchstart", start);
      el.removeEventListener("touchmove", move);
      el.removeEventListener("touchend", end);
      el.removeEventListener("wheel", wheel);
    };
  }, []);

  const colW = Math.round(78 * zoom);
  const rowH = Math.round(48 * zoom);
  const railW = 56;
  const boardW = railW + colW * 7;
  const boardH = rowH * SLOT_COUNT;
  const todayDow = new Date().getDay() + 1;
  const hours = hourLabels();
  const times = timeOptions();

  const openTasks = school.tasks
    .filter((task) => !task.is_completed)
    .sort((a, b) => a.due_date.localeCompare(b.due_date));

  const subjectOf = (id: number) => school.subjects.find((subject) => subject.id === id);

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-2">
        <div>
          <p className="text-sm font-semibold">{t("fromTo")}</p>
          {school.slots.length === 0 ? <p className="text-sm text-muted">{t("noClassesHint")}</p> : null}
        </div>
        <div className="flex items-center">
          <IconButton label={t("zoomOut")} onClick={() => { haptic(8); setZoom((value) => clampZoom(value - 0.1)); }}>
            <ZoomOut className="size-5" />
          </IconButton>
          <button
            type="button"
            aria-label={t("zoomReset")}
            onClick={() => { haptic(8); setZoom(1); }}
            className="press min-h-11 min-w-14 rounded-full text-sm font-bold tabular-nums"
          >
            {Math.round(zoom * 100)}%
          </button>
          <IconButton label={t("zoomIn")} onClick={() => { haptic(8); setZoom((value) => clampZoom(value + 0.1)); }}>
            <ZoomIn className="size-5" />
          </IconButton>
        </div>
      </div>

      {openTasks.length > 0 ? (
        <div className="mb-3">
          <p className="mb-1 text-xs font-semibold text-muted">{t("upcoming")}</p>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {openTasks.map((task) => {
              const subject = subjectOf(task.subject_id);
              return (
                <label key={task.id} className="flex min-w-44 shrink-0 items-start gap-2 rounded-xl border border-border bg-surface px-3 py-2">
                  <input
                    type="checkbox"
                    className="mt-1 size-4 accent-primary"
                    aria-label={t("markDone")}
                    onChange={() => {
                      haptic(10);
                      void school.toggleTask(task.id, true);
                    }}
                  />
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold">{task.title}</span>
                    <span className="block truncate text-xs text-muted">
                      {subject?.name ?? ""} · {formatDate(school.settings.lang, task.due_date)}
                    </span>
                  </span>
                </label>
              );
            })}
          </div>
        </div>
      ) : null}

      <div className="mb-3">
        <PrimaryButton
          onClick={() => {
            haptic(10);
            setAdding({ day: todayDow, start: "08:00" });
          }}
        >
          <Plus className="size-4" />
          {t("addClass")}
        </PrimaryButton>
      </div>

      <div ref={scroller} className="board-scroll overflow-auto rounded-xl border border-border bg-surface">
        <div style={{ width: boardW }}>
          <div className="sticky top-0 z-20 flex border-b border-border bg-surface">
            <div className="shrink-0" style={{ width: railW }} />
            {Array.from({ length: 7 }, (_, index) => {
              const day = index + 1;
              const today = day === todayDow;
              return (
                <div
                  key={day}
                  style={{ width: colW }}
                  className={`shrink-0 border-s border-border px-1 py-2 text-center text-xs font-bold ${today ? "text-primary" : "text-muted"}`}
                >
                  <div>{weekdayName(school.settings.lang, day)}</div>
                  {today ? <div className="font-medium">{t("today")}</div> : null}
                </div>
              );
            })}
          </div>
          <div className="relative flex" style={{ height: boardH }}>
            <div className="sticky start-0 z-10 shrink-0 border-e border-border bg-surface" style={{ width: railW }}>
              {hours.map((hour, index) => (
                <div
                  key={hour}
                  className="absolute inset-x-0 px-1 text-xs text-muted tabular-nums"
                  style={{ top: index * rowH + 2 }}
                >
                  {toHHMM(hour * 60)}
                </div>
              ))}
            </div>
            {Array.from({ length: 7 }, (_, index) => {
              const day = index + 1;
              const placed = placeDay(school.slots.filter((slot) => slot.day_of_week === day));
              return (
                <div
                  key={day}
                  className={`isolate relative shrink-0 border-s border-border ${day === todayDow ? "today-col" : ""}`}
                  style={{ width: colW, height: boardH }}
                >
                  {hours.map((hour, hourIndex) => (
                    <button
                      key={hour}
                      type="button"
                      className="absolute inset-x-0 border-b border-border hover:bg-surface-2"
                      style={{ top: hourIndex * rowH, height: rowH }}
                      aria-label={`${t("addClass")} ${weekdayName(school.settings.lang, day, "long")} ${toHHMM(hour * 60)}`}
                      onClick={() => {
                        haptic(8);
                        setAdding({ day, start: toHHMM(hour * 60) });
                      }}
                    />
                  ))}
                  {placed.map((item) => {
                    const subject = subjectOf(item.slot.subject_id);
                    if (!subject) return null;
                    const span = DAY_END - DAY_START;
                    const start = Math.max(item.start, DAY_START);
                    const end = Math.min(Math.max(item.end, start + 30), DAY_END);
                    const top = ((start - DAY_START) / span) * 100;
                    const height = ((end - start) / span) * 100;
                    const hasTask = school.tasks.some((task) => task.subject_id === subject.id && !task.is_completed);
                    const hasFile = school.attachments.some((file) => file.subject_id === subject.id);
                    return (
                      <button
                        key={item.slot.id}
                        type="button"
                        className="absolute z-10 overflow-hidden rounded-md px-1 py-0.5 text-start"
                        style={{
                          top: `calc(${top}% + 2px)`,
                          height: `calc(${height}% - 4px)`,
                          width: `calc(${100 / item.lanes}% - 4px)`,
                          insetInlineStart: `calc(${(item.lane * 100) / item.lanes}% + 2px)`,
                          background: subject.color,
                          color: foregroundFor(subject.color),
                        }}
                        onClick={() => {
                          haptic(10);
                          setMode("menu");
                          setOpenId(item.slot.id);
                        }}
                      >
                        <span className="block truncate text-xs font-bold">{subject.name}</span>
                        <span className="block truncate text-xs">{subject.teacher}</span>
                        {(hasTask || hasFile) && (
                          <span className="mt-0.5 flex gap-1">
                            {hasTask ? <Bell className="size-3" aria-hidden="true" /> : null}
                            {hasFile ? <Paperclip className="size-3" aria-hidden="true" /> : null}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {adding ? (
        <AddClassDialog
          day={adding.day}
          start={adding.start}
          times={times}
          onClose={() => setAdding(null)}
        />
      ) : null}
      {openId != null ? (
        <ClassDialog
          slotId={openId}
          mode={mode}
          setMode={setMode}
          onClose={() => setOpenId(null)}
          onPreview={setPreview}
        />
      ) : null}
      {preview ? <FilePreview preview={preview} onClose={() => setPreview(null)} /> : null}
    </div>
  );
}

function AddClassDialog({
  day,
  start,
  times,
  onClose,
}: {
  day: number;
  start: string;
  times: string[];
  onClose: () => void;
}) {
  const school = useSchool();
  const t = useT();
  const [dayValue, setDayValue] = useState(day);
  const [name, setName] = useState("");
  const [teacher, setTeacher] = useState("");
  const [color, setColor] = useState(SUBJECT_COLORS[0]);
  const [coef, setCoef] = useState("1");
  const [startValue, setStartValue] = useState(start);
  const [endValue, setEndValue] = useState(toHHMM(Math.min(toMin(start) + 60, DAY_END)));
  const [error, setError] = useState("");
  const [listOpen, setListOpen] = useState(false);

  const suggestions = useMemo(() => {
    const query = name.trim().toLowerCase();
    if (!query) return school.subjects.slice(0, 6);
    return school.subjects.filter((subject) => subject.name.toLowerCase().includes(query)).slice(0, 6);
  }, [name, school.subjects]);

  const matched = school.subjects.find((subject) => subject.name.trim().toLowerCase() === name.trim().toLowerCase());

  const submit = async () => {
    const coefficient = Number(coef.replace(",", "."));
    if (!name.trim() || !teacher.trim() || !Number.isFinite(coefficient) || coefficient <= 0) {
      setError(t("required"));
      return;
    }
    if (toMin(endValue) <= toMin(startValue)) {
      setError(t("timeOrder"));
      return;
    }
    try {
      await school.saveClass({
        name,
        teacher,
        color,
        coefficient,
        day: dayValue,
        start: startValue,
        end: endValue,
      });
      haptic(16);
      school.flash(t("classSaved"));
      onClose();
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  return (
    <Modal title={t("addClass")} onClose={onClose}>
      <Field label={t("day")}>
        <select className={fieldClass} value={dayValue} onChange={(event) => setDayValue(Number(event.target.value))}>
          {Array.from({ length: 7 }, (_, index) => (
            <option key={index + 1} value={index + 1}>
              {weekdayName(school.settings.lang, index + 1, "long")}
            </option>
          ))}
        </select>
      </Field>
      <Field label={t("subject")}>
        <input
          className={fieldClass}
          value={name}
          autoComplete="off"
          onChange={(event) => {
            setName(event.target.value);
            setListOpen(true);
          }}
          onFocus={() => setListOpen(true)}
        />
        {listOpen && suggestions.length > 0 ? (
          <ul className="mt-1 overflow-hidden rounded-lg border border-border bg-bg">
            {suggestions.map((subject) => (
              <li key={subject.id}>
                <button
                  type="button"
                  className="flex w-full items-center gap-2 px-3 py-2 text-start text-sm hover:bg-surface-2"
                  onClick={() => {
                    setName(subject.name);
                    setTeacher(subject.teacher);
                    setColor(subject.color);
                    setCoef(String(subject.coefficient));
                    setListOpen(false);
                    haptic(8);
                  }}
                >
                  <span className="size-3 rounded-full" style={{ background: subject.color }} />
                  <span className="min-w-0 flex-1 truncate">{subject.name}</span>
                  <span className="truncate text-muted">{subject.teacher}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : null}
      </Field>
      <Field label={t("teacherName")}>
        <input className={fieldClass} value={teacher} onChange={(event) => setTeacher(event.target.value)} />
      </Field>
      <div className="grid grid-cols-2 gap-2">
        <Field label={t("start")}>
          <select dir="ltr" className={fieldClass} value={startValue} onChange={(event) => setStartValue(event.target.value)}>
            {times.map((time) => (
              <option key={time}>{time}</option>
            ))}
          </select>
        </Field>
        <Field label={t("end")}>
          <select dir="ltr" className={fieldClass} value={endValue} onChange={(event) => setEndValue(event.target.value)}>
            {times.map((time) => (
              <option key={time}>{time}</option>
            ))}
          </select>
        </Field>
      </div>
      <Field label={t("coefficient")}>
        <input
          dir="ltr"
          inputMode="decimal"
          className={fieldClass}
          value={coef}
          onChange={(event) => setCoef(event.target.value)}
        />
      </Field>
      <fieldset className="mb-3">
        <legend className="mb-1 text-sm font-medium">{t("color")}</legend>
        <div className="flex flex-wrap gap-2">
          {SUBJECT_COLORS.map((swatch) => (
            <button
              key={swatch}
              type="button"
              aria-label={swatch}
              aria-pressed={color === swatch}
              onClick={() => setColor(swatch)}
              className="size-11 rounded-full border-2"
              style={{
                background: swatch,
                borderColor: color === swatch ? "var(--fg)" : "transparent",
              }}
            />
          ))}
        </div>
        {matched ? <p className="mt-2 text-xs text-muted">{t("colorShared")}</p> : null}
      </fieldset>
      {error ? <p className="mb-3 text-sm text-danger">{error}</p> : null}
      <div className="flex gap-2">
        <GhostButton onClick={onClose}>{t("cancel")}</GhostButton>
        <PrimaryButton onClick={() => void submit()}>{t("save")}</PrimaryButton>
      </div>
    </Modal>
  );
}

function ClassDialog({
  slotId,
  mode,
  setMode,
  onClose,
  onPreview,
}: {
  slotId: number;
  mode: "menu" | "task" | "file" | "confirm";
  setMode: (mode: "menu" | "task" | "file" | "confirm") => void;
  onClose: () => void;
  onPreview: (preview: Preview) => void;
}) {
  const school = useSchool();
  const t = useT();
  const slot = school.slots.find((item) => item.id === slotId);
  const subject = school.subjects.find((item) => item.id === slot?.subject_id);
  const [title, setTitle] = useState("");
  const [due, setDue] = useState(tomorrowIso());
  const [fileTitle, setFileTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState("");
  const imageRef = useRef<HTMLInputElement>(null);
  const pdfRef = useRef<HTMLInputElement>(null);

  if (!slot || !subject) return null;
  const tasks = school.tasks.filter((task) => task.subject_id === subject.id);
  const files = school.attachments.filter((item) => item.subject_id === subject.id);

  const saveTask = async () => {
    if (!title.trim() || !due) {
      setError(t("required"));
      return;
    }
    try {
      const permitted = await school.addTask({ subjectId: subject.id, title, due });
      haptic(16);
      school.flash(permitted ? t("reminderSet") : t("reminderOff"));
      setTitle("");
      setMode("menu");
      setError("");
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  const saveFile = async () => {
    if (!fileTitle.trim() || !file) {
      setError(!file ? t("chooseFile") : t("required"));
      return;
    }
    const type = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf") ? "pdf" : "image";
    try {
      await school.addAttachment({
        subjectId: subject.id,
        title: fileTitle,
        type,
        file,
        filename: file.name,
      });
      haptic(16);
      school.flash(t("saved"));
      setFile(null);
      setFileTitle("");
      setMode("menu");
      setError("");
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  const removeClass = async () => {
    try {
      await school.deleteSlot(slot.id);
      haptic(16);
      school.flash(t("deleted"));
      onClose();
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  const openFile = (item: Attachment) => {
    const url = URL.createObjectURL(item.blob);
    onPreview({ url, title: item.title, type: item.type, filename: item.file_path });
  };

  return (
    <Modal title={subject.name} onClose={onClose}>
      <p className="mb-1 text-sm text-muted">{subject.teacher}</p>
      <p className="mb-4 text-sm font-semibold tabular-nums" dir="ltr">
        {weekdayName(school.settings.lang, slot.day_of_week, "long")} · {slot.start_time}–{slot.end_time}
      </p>
      <p className="mb-4 text-xs text-muted">
        {t("coefShort")} {subject.coefficient}
      </p>

      {mode === "menu" ? (
        <div className="mb-4 grid gap-2">
          <GhostButton onClick={() => { setError(""); setMode("task"); }}>
            <Bell className="size-4" /> {t("addTask")}
          </GhostButton>
          <GhostButton onClick={() => { setError(""); setMode("file"); }}>
            <Paperclip className="size-4" /> {t("addFile")}
          </GhostButton>
          <GhostButton danger onClick={() => setMode("confirm")}>
            <Trash2 className="size-4" /> {t("deleteClass")}
          </GhostButton>
        </div>
      ) : null}

      {mode === "task" ? (
        <div className="mb-4">
          <Field label={t("taskTitle")}>
            <input className={fieldClass} value={title} onChange={(event) => setTitle(event.target.value)} />
          </Field>
          <Field label={t("dueDate")}>
            <input dir="ltr" type="date" className={fieldClass} value={due} onChange={(event) => setDue(event.target.value)} />
          </Field>
          {error ? <p className="mb-2 text-sm text-danger">{error}</p> : null}
          <div className="flex gap-2">
            <GhostButton onClick={() => setMode("menu")}>{t("back")}</GhostButton>
            <PrimaryButton onClick={() => void saveTask()}>{t("save")}</PrimaryButton>
          </div>
        </div>
      ) : null}

      {mode === "file" ? (
        <div className="mb-4">
          <Field label={t("fileTitle")}>
            <input className={fieldClass} value={fileTitle} onChange={(event) => setFileTitle(event.target.value)} />
          </Field>
          <input
            ref={imageRef}
            hidden
            type="file"
            accept="image/*"
            onChange={(event) => {
              const picked = event.target.files?.[0];
              if (!picked) return;
              setFile(picked);
              if (!fileTitle.trim()) setFileTitle(picked.name.replace(/\.[^.]+$/, ""));
            }}
          />
          <input
            ref={pdfRef}
            hidden
            type="file"
            accept="application/pdf"
            onChange={(event) => {
              const picked = event.target.files?.[0];
              if (!picked) return;
              setFile(picked);
              if (!fileTitle.trim()) setFileTitle(picked.name.replace(/\.[^.]+$/, ""));
            }}
          />
          <div className="mb-3 flex gap-2">
            <GhostButton onClick={() => imageRef.current?.click()}>{t("pickImage")}</GhostButton>
            <GhostButton onClick={() => pdfRef.current?.click()}>{t("pickPdf")}</GhostButton>
          </div>
          {file ? <p className="mb-2 truncate text-sm text-muted">{file.name}</p> : null}
          {error ? <p className="mb-2 text-sm text-danger">{error}</p> : null}
          <div className="flex gap-2">
            <GhostButton onClick={() => setMode("menu")}>{t("back")}</GhostButton>
            <PrimaryButton onClick={() => void saveFile()}>{t("save")}</PrimaryButton>
          </div>
        </div>
      ) : null}

      {mode === "confirm" ? (
        <div className="mb-4">
          <p className="mb-3 text-sm">{t("confirmDeleteClass")}</p>
          <div className="flex gap-2">
            <GhostButton onClick={() => setMode("menu")}>{t("cancel")}</GhostButton>
            <GhostButton danger onClick={() => void removeClass()}>{t("delete")}</GhostButton>
          </div>
        </div>
      ) : null}

      <h3 className="mb-2 text-sm font-bold">{t("tasks")}</h3>
      {tasks.length === 0 ? <p className="mb-4 text-sm text-muted">{t("noTasks")}</p> : (
        <ul className="mb-4 grid gap-2">
          {tasks.map((task) => (
            <li key={task.id} className="flex items-center gap-2 rounded-lg border border-border px-2 py-1">
              <button
                type="button"
                aria-label={task.is_completed ? t("markOpen") : t("markDone")}
                className="grid size-11 place-items-center"
                onClick={() => {
                  haptic(8);
                  void school.toggleTask(task.id, !task.is_completed);
                }}
              >
                <Check className={`size-4 ${task.is_completed ? "text-ok" : "text-muted"}`} />
              </button>
              <span className={`min-w-0 flex-1 ${task.is_completed ? "text-muted line-through" : ""}`}>
                <span className="block truncate text-sm font-medium">{task.title}</span>
                <span className="block text-xs text-muted">{formatDate(school.settings.lang, task.due_date)}</span>
              </span>
              <button
                type="button"
                aria-label={t("delete")}
                className="grid size-11 place-items-center text-danger"
                onClick={() => void school.deleteTask(task.id)}
              >
                <Trash2 className="size-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      <h3 className="mb-2 text-sm font-bold">{t("files")}</h3>
      {files.length === 0 ? <p className="text-sm text-muted">{t("noFiles")}</p> : (
        <ul className="grid gap-2">
          {files.map((item) => (
            <li key={item.id} className="flex items-center gap-2 rounded-lg border border-border px-3 py-2">
              <button type="button" className="min-w-0 flex-1 text-start" onClick={() => openFile(item)}>
                <span className="block truncate text-sm font-medium">{item.title}</span>
                <span className="block text-xs text-muted">
                  {item.type === "pdf" ? t("pdf") : t("image")} · {t("uploadDate")} {formatDate(school.settings.lang, item.upload_date)}
                </span>
              </button>
              <button
                type="button"
                aria-label={t("delete")}
                className="grid size-11 place-items-center text-danger"
                onClick={() => void school.deleteAttachment(item.id)}
              >
                <Trash2 className="size-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </Modal>
  );
}

function FilePreview({ preview, onClose }: { preview: Preview; onClose: () => void }) {
  const t = useT();
  useEffect(() => () => URL.revokeObjectURL(preview.url), [preview.url]);
  return (
    <Modal title={preview.title} onClose={onClose}>
      {preview.type === "image" ? (
        <img src={preview.url} alt={preview.title} className="mb-3 max-h-[60dvh] w-full rounded-lg object-contain" />
      ) : (
        <iframe title={preview.title} src={preview.url} className="mb-3 h-[60dvh] w-full rounded-lg border border-border" />
      )}
      <a className="press inline-flex h-11 items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg" href={preview.url} download={preview.filename}>
        {t("download")}
      </a>
    </Modal>
  );
}
