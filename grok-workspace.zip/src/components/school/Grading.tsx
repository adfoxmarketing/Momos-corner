import { Download, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Field, GhostButton, Modal, PrimaryButton, fieldClass } from "@/components/school/ui";
import { formatMark, haptic, parseMark, shareCsv } from "@/lib/school/format";
import { averageOf } from "@/lib/school/grades";
import { useSchool, useT } from "@/lib/school/store";
import { MARK_FIELDS, emptyMarks, type MarkField } from "@/lib/school/types";

export function Grading() {
  const school = useSchool();
  const t = useT();
  const [sectionId, setSectionId] = useState<number | null>(school.sections[0]?.id ?? null);
  const [termId, setTermId] = useState<number | null>(school.terms[0]?.id ?? null);
  const [dialog, setDialog] = useState<
    | { type: "section" }
    | { type: "term" }
    | { type: "del-section" }
    | { type: "del-term" }
    | { type: "student" }
    | { type: "edit"; id: number }
    | null
  >(null);

  useEffect(() => {
    if (!school.sections.some((section) => section.id === sectionId)) {
      setSectionId(school.sections[0]?.id ?? null);
    }
  }, [school.sections, sectionId]);

  useEffect(() => {
    if (!school.terms.some((term) => term.id === termId)) {
      setTermId(school.terms[0]?.id ?? null);
    }
  }, [school.terms, termId]);

  const section = school.sections.find((item) => item.id === sectionId) ?? null;
  const term = school.terms.find((item) => item.id === termId) ?? null;
  const students = school.teacherGrades
    .filter((grade) => grade.section_id === sectionId && grade.term_id === termId)
    .sort((a, b) => a.student_name.localeCompare(b.student_name, school.settings.lang));

  const exportSheet = async () => {
    if (!section || !term) return;
    const header = [t("studentName"), t("cc"), t("tp"), t("dev1"), t("dev2"), t("exam"), t("average")];
    const body = students.map((student) => {
      const avg = averageOf(student);
      return [
        student.student_name,
        student.cc,
        student.tp,
        student.dev1,
        student.dev2,
        student.exam,
        avg == null ? "" : formatMark(school.settings.lang, avg),
      ];
    });
    const rows = [[t("sections"), section.name], [t("terms"), term.name], [], header, ...body];
    const filename = `grades-${section.name}-${term.name}.csv`.replaceAll(/\s+/g, "-");
    try {
      const result = await shareCsv(filename, rows);
      if (result === "cancelled") return;
      haptic(12);
      school.flash(result === "shared" ? t("shared") : t("exported"));
    } catch (error) {
      console.error(error);
      school.flash(t("errorGeneric"));
    }
  };

  return (
    <div>
      <div className="mb-3 grid gap-3 sm:grid-cols-2">
        <Picker
          label={t("sections")}
          value={sectionId}
          options={school.sections.map((item) => ({ id: item.id, name: item.name }))}
          onChange={setSectionId}
          onAdd={() => setDialog({ type: "section" })}
          onDelete={() => setDialog({ type: "del-section" })}
          addLabel={t("addSection")}
          deleteLabel={t("deleteSection")}
          canDelete={sectionId != null}
        />
        <Picker
          label={t("terms")}
          value={termId}
          options={school.terms.map((item) => ({ id: item.id, name: item.name }))}
          onChange={setTermId}
          onAdd={() => setDialog({ type: "term" })}
          onDelete={() => setDialog({ type: "del-term" })}
          addLabel={t("addTerm")}
          deleteLabel={t("deleteTerm")}
          canDelete={termId != null}
        />
      </div>

      <div className="mb-4">
        <PrimaryButton onClick={() => void exportSheet()} disabled={!section || !term || students.length === 0}>
          <Download className="size-4" />
          {t("exportExcel")}
        </PrimaryButton>
      </div>

      {!section || !term ? (
        <p className="rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted">{t("needSectionTerm")}</p>
      ) : (
        <>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold">{t("students")}</h2>
            <PrimaryButton onClick={() => setDialog({ type: "student" })}>
              <Plus className="size-4" />
              {t("addStudent")}
            </PrimaryButton>
          </div>
          {students.length === 0 ? (
            <p className="rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted">{t("noStudents")}</p>
          ) : (
            <ul className="grid gap-2">
              {students.map((student) => {
                const avg = averageOf(student);
                return (
                  <li key={student.id}>
                    <button
                      type="button"
                      onClick={() => {
                        haptic(8);
                        setDialog({ type: "edit", id: student.id });
                      }}
                      className="press flex w-full items-center gap-3 rounded-xl border border-border bg-surface px-3 py-3 text-start"
                    >
                      <span className="grid size-10 place-items-center rounded-full bg-surface-2 text-sm font-bold">
                        {student.student_name.slice(0, 1)}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate font-semibold">{student.student_name}</span>
                        <span className="block text-xs text-muted">{t("editGrades")}</span>
                      </span>
                      <span className="text-end">
                        <span className="block text-xs text-muted">{t("average")}</span>
                        <span className="block font-bold tabular-nums">{avg == null ? "—" : formatMark(school.settings.lang, avg)}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </>
      )}

      {dialog?.type === "section" ? (
        <NameDialog
          title={t("addSection")}
          label={t("sectionName")}
          onClose={() => setDialog(null)}
          onSave={async (name) => {
            await school.addSection(name);
            school.flash(t("saved"));
          }}
        />
      ) : null}
      {dialog?.type === "term" ? (
        <NameDialog
          title={t("addTerm")}
          label={t("termName")}
          onClose={() => setDialog(null)}
          onSave={async (name) => {
            await school.addTerm(name);
            school.flash(t("saved"));
          }}
        />
      ) : null}
      {dialog?.type === "del-section" && section ? (
        <ConfirmDialog
          title={t("deleteSection")}
          body={t("confirmDeleteSection")}
          onClose={() => setDialog(null)}
          onConfirm={async () => {
            await school.deleteSection(section.id);
            school.flash(t("deleted"));
          }}
        />
      ) : null}
      {dialog?.type === "del-term" && term ? (
        <ConfirmDialog
          title={t("deleteTerm")}
          body={t("confirmDeleteTerm")}
          onClose={() => setDialog(null)}
          onConfirm={async () => {
            await school.deleteTerm(term.id);
            school.flash(t("deleted"));
          }}
        />
      ) : null}
      {dialog?.type === "student" && section && term ? (
        <NameDialog
          title={t("addStudent")}
          label={t("studentName")}
          onClose={() => setDialog(null)}
          onSave={async (name) => {
            await school.addTeacherStudent({ sectionId: section.id, termId: term.id, name });
            school.flash(t("saved"));
          }}
        />
      ) : null}
      {dialog?.type === "edit" ? (
        <StudentEditor id={dialog.id} onClose={() => setDialog(null)} />
      ) : null}
    </div>
  );
}

function Picker({
  label,
  value,
  options,
  onChange,
  onAdd,
  onDelete,
  addLabel,
  deleteLabel,
  canDelete,
}: {
  label: string;
  value: number | null;
  options: { id: number; name: string }[];
  onChange: (id: number) => void;
  onAdd: () => void;
  onDelete: () => void;
  addLabel: string;
  deleteLabel: string;
  canDelete: boolean;
}) {
  return (
    <div>
      <span className="mb-1 block text-sm font-medium">{label}</span>
      <div className="flex gap-2">
        <select
          className={fieldClass}
          value={value ?? ""}
          onChange={(event) => onChange(Number(event.target.value))}
        >
          {options.length === 0 ? <option value="">{label}</option> : null}
          {options.map((option) => (
            <option key={option.id} value={option.id}>
              {option.name}
            </option>
          ))}
        </select>
        <button type="button" aria-label={addLabel} onClick={onAdd} className="press grid size-11 shrink-0 place-items-center rounded-lg bg-primary text-primary-fg">
          <Plus className="size-5" />
        </button>
        <button
          type="button"
          aria-label={deleteLabel}
          disabled={!canDelete}
          onClick={onDelete}
          className="press grid size-11 shrink-0 place-items-center rounded-lg border border-danger text-danger disabled:opacity-40"
        >
          <Trash2 className="size-5" />
        </button>
      </div>
    </div>
  );
}

function NameDialog({
  title,
  label,
  onClose,
  onSave,
}: {
  title: string;
  label: string;
  onClose: () => void;
  onSave: (name: string) => Promise<void>;
}) {
  const school = useSchool();
  const t = useT();
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const submit = async () => {
    if (!name.trim()) {
      setError(t("required"));
      return;
    }
    try {
      await onSave(name);
      haptic(12);
      onClose();
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  return (
    <Modal title={title} onClose={onClose}>
      <Field label={label}>
        <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} />
      </Field>
      {error ? <p className="mb-3 text-sm text-danger">{error}</p> : null}
      <div className="flex gap-2">
        <GhostButton onClick={onClose}>{t("cancel")}</GhostButton>
        <PrimaryButton onClick={() => void submit()}>{t("save")}</PrimaryButton>
      </div>
    </Modal>
  );
}

function ConfirmDialog({
  title,
  body,
  onClose,
  onConfirm,
}: {
  title: string;
  body: string;
  onClose: () => void;
  onConfirm: () => Promise<void>;
}) {
  const school = useSchool();
  const t = useT();
  return (
    <Modal title={title} onClose={onClose}>
      <p className="mb-4 text-sm">{body}</p>
      <div className="flex gap-2">
        <GhostButton onClick={onClose}>{t("cancel")}</GhostButton>
        <GhostButton
          danger
          onClick={() => {
            void onConfirm()
              .then(() => {
                haptic(12);
                onClose();
              })
              .catch((error) => {
                console.error(error);
                school.flash(t("errorGeneric"));
              });
          }}
        >
          {t("delete")}
        </GhostButton>
      </div>
    </Modal>
  );
}

function StudentEditor({ id, onClose }: { id: number; onClose: () => void }) {
  const school = useSchool();
  const t = useT();
  const row = school.teacherGrades.find((grade) => grade.id === id);
  const [name, setName] = useState(row?.student_name ?? "");
  const [texts, setTexts] = useState<Record<MarkField, string>>(() => ({
    cc: row?.cc == null ? "" : String(row.cc),
    tp: row?.tp == null ? "" : String(row.tp),
    dev1: row?.dev1 == null ? "" : String(row.dev1),
    dev2: row?.dev2 == null ? "" : String(row.dev2),
    exam: row?.exam == null ? "" : String(row.exam),
  }));
  const [error, setError] = useState("");
  const [confirm, setConfirm] = useState(false);

  if (!row) return null;
  const draft = emptyMarks();
  let draftOk = true;
  for (const field of MARK_FIELDS) {
    const parsed = parseMark(texts[field]);
    if (parsed === "invalid") draftOk = false;
    else draft[field] = parsed;
  }
  const avg = draftOk ? averageOf({ ...row, ...draft }) : null;

  const save = async () => {
    if (!name.trim()) {
      setError(t("required"));
      return;
    }
    const nextMarks = { ...emptyMarks() };
    for (const field of MARK_FIELDS) {
      const parsed = parseMark(texts[field]);
      if (parsed === "invalid") {
        setError(t("invalidMark"));
        return;
      }
      nextMarks[field] = parsed;
    }
    try {
      await school.updateTeacherGrade({ ...row, student_name: name.trim(), ...nextMarks });
      haptic(12);
      school.flash(t("saved"));
      onClose();
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  return (
    <Modal title={t("editGrades")} onClose={onClose}>
      <Field label={t("studentName")}>
        <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} />
      </Field>
      <div className="mb-3 grid grid-cols-2 gap-2">
        {MARK_FIELDS.map((field) => (
          <Field key={field} label={t(field)}>
            <input
              dir="ltr"
              inputMode="decimal"
              className={fieldClass}
              value={texts[field]}
              onChange={(event) => setTexts((current) => ({ ...current, [field]: event.target.value }))}
            />
          </Field>
        ))}
      </div>
      <p className="mb-3 text-sm">
        {t("average")}: <span className="font-bold tabular-nums">{avg == null ? "—" : formatMark(school.settings.lang, avg)}</span>
      </p>
      {error ? <p className="mb-3 text-sm text-danger">{error}</p> : null}
      {confirm ? (
        <div className="mb-3">
          <p className="mb-2 text-sm">{t("confirmDeleteStudent")}</p>
          <div className="flex gap-2">
            <GhostButton onClick={() => setConfirm(false)}>{t("cancel")}</GhostButton>
            <GhostButton
              danger
              onClick={() => {
                void school.deleteTeacherGrade(row.id).then(() => {
                  haptic(12);
                  school.flash(t("deleted"));
                  onClose();
                });
              }}
            >
              {t("delete")}
            </GhostButton>
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          <GhostButton onClick={onClose}>{t("cancel")}</GhostButton>
          <GhostButton danger onClick={() => setConfirm(true)}>{t("deleteStudent")}</GhostButton>
          <PrimaryButton onClick={() => void save()}>{t("save")}</PrimaryButton>
        </div>
      )}
    </Modal>
  );
}
