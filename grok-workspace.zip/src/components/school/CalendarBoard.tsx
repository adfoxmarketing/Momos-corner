import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { Field, GhostButton, Modal, PrimaryButton } from "@/components/school/ui";
import { formatDate, haptic, isoDate, monthName, weekdayName } from "@/lib/school/format";
import { useSchool, useT } from "@/lib/school/store";

export function CalendarBoard() {
  const school = useSchool();
  const t = useT();
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const [day, setDay] = useState<number | null>(null);

  const firstDow = new Date(year, month, 1).getDay();
  const count = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(firstDow).fill(null)];
  for (let d = 1; d <= count; d += 1) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  const selectedIso = day == null ? null : isoDate(year, month, day);
  const selectedNote = school.notes.find((note) => note.date === selectedIso);

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <button
          type="button"
          aria-label={String(year - 1)}
          className="press grid size-11 place-items-center rounded-full hover:bg-surface-2"
          onClick={() => setYear((value) => value - 1)}
        >
          <ChevronLeft className="size-5 rtl:rotate-180" />
        </button>
        <p className="text-lg font-bold tabular-nums">{year}</p>
        <button
          type="button"
          aria-label={String(year + 1)}
          className="press grid size-11 place-items-center rounded-full hover:bg-surface-2"
          onClick={() => setYear((value) => value + 1)}
        >
          <ChevronRight className="size-5 rtl:rotate-180" />
        </button>
      </div>
      <div className="mb-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
        {Array.from({ length: 12 }, (_, index) => {
          const active = index === month;
          return (
            <button
              key={index}
              type="button"
              onClick={() => {
                haptic(8);
                setMonth(index);
              }}
              className={`press h-11 rounded-lg border text-sm font-semibold ${
                active ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"
              }`}
            >
              {monthName(school.settings.lang, index)}
            </button>
          );
        })}
      </div>
      <div className="overflow-hidden rounded-xl border border-border bg-surface">
        <div className="grid grid-cols-7 border-b border-border bg-surface-2 text-center text-xs font-semibold text-muted">
          {Array.from({ length: 7 }, (_, index) => (
            <div key={index} className="py-2">
              {weekdayName(school.settings.lang, index + 1)}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {cells.map((value, index) => {
            if (value == null) return <div key={`e-${index}`} className="min-h-16 border-b border-e border-border" />;
            const iso = isoDate(year, month, value);
            const note = school.notes.find((item) => item.date === iso);
            const isToday = iso === isoDate(now.getFullYear(), now.getMonth(), now.getDate());
            return (
              <button
                key={iso}
                type="button"
                onClick={() => {
                  haptic(8);
                  setDay(value);
                }}
                className="press min-h-16 border-b border-e border-border p-1.5 text-start hover:bg-surface-2"
              >
                <span className={`inline-grid size-7 place-items-center rounded-full text-sm font-semibold ${isToday ? "bg-primary text-primary-fg" : ""}`}>
                  {value}
                </span>
                {note ? <span className="mt-1 block truncate text-xs text-muted">{note.note}</span> : null}
              </button>
            );
          })}
        </div>
      </div>
      {selectedIso ? (
        <NoteDialog
          iso={selectedIso}
          initial={selectedNote?.note ?? ""}
          onClose={() => setDay(null)}
        />
      ) : null}
    </div>
  );
}

function NoteDialog({ iso, initial, onClose }: { iso: string; initial: string; onClose: () => void }) {
  const school = useSchool();
  const t = useT();
  const [text, setText] = useState(initial);

  const save = async (next: string) => {
    try {
      await school.saveNote(iso, next);
      haptic(12);
      school.flash(t("saved"));
      onClose();
    } catch (error) {
      console.error(error);
      school.flash(t("errorGeneric"));
    }
  };

  return (
    <Modal title={formatDate(school.settings.lang, iso)} onClose={onClose}>
      <Field label={t("calendar")}>
        <textarea
          className="min-h-36 w-full rounded-lg border border-border bg-bg px-3 py-2 text-base text-fg"
          value={text}
          placeholder={t("notePlaceholder")}
          onChange={(event) => setText(event.target.value)}
        />
      </Field>
      <div className="flex flex-wrap gap-2">
        <GhostButton onClick={onClose}>{t("cancel")}</GhostButton>
        {initial ? <GhostButton danger onClick={() => void save("")}>{t("clearNote")}</GhostButton> : null}
        <PrimaryButton onClick={() => void save(text)}>{t("save")}</PrimaryButton>
      </div>
    </Modal>
  );
}
