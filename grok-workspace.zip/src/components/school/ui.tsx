import { X } from "lucide-react";
import { useEffect, useRef, type ReactNode } from "react";
import { useT } from "@/lib/school/store";

export const fieldClass =
  "h-11 w-full rounded-lg border border-border bg-bg px-3 text-base text-fg";

export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path d="M8 22 24 10l16 12" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
      <path d="M12 21.5V38h24V21.5" fill="none" stroke="currentColor" strokeWidth="2.5" />
      <path d="M21 38V28h6v10" fill="none" stroke="currentColor" strokeWidth="2.5" />
    </svg>
  );
}

export function IconButton({
  label,
  onClick,
  children,
  pressed,
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
  pressed?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={pressed}
      onClick={onClick}
      className="press grid size-11 place-items-center rounded-full text-fg hover:bg-surface-2"
    >
      {children}
    </button>
  );
}

export function PrimaryButton({
  children,
  onClick,
  type = "button",
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className="press inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg disabled:opacity-50"
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  onClick,
  danger,
}: {
  children: ReactNode;
  onClick?: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`press inline-flex h-11 items-center justify-center gap-2 rounded-lg border px-4 text-sm font-semibold ${
        danger ? "border-danger text-danger" : "border-border bg-surface text-fg"
      }`}
    >
      {children}
    </button>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const t = useT();
  const panel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panel.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div className="stage-3d fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button type="button" aria-label={t("close")} className="absolute inset-0 bg-fg/40 backdrop-blur-md" onClick={onClose} />
      <div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        className="panel-3d animate-rise relative max-h-[92dvh] w-full overflow-y-auto rounded-t-2xl border border-border bg-surface sm:max-w-md sm:rounded-2xl"
      >
        <div className="sticky top-0 z-10 flex items-center gap-2 border-b border-border bg-surface px-4 py-3">
          <h2 className="min-w-0 flex-1 truncate text-base font-bold">{title}</h2>
          <button type="button" aria-label={t("close")} onClick={onClose} className="press grid size-11 place-items-center rounded-full hover:bg-surface-2">
            <X className="size-5" />
          </button>
        </div>
        <div className="px-4 py-4">{children}</div>
      </div>
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="mb-3 block">
      <span className="mb-1 block text-sm font-medium">{label}</span>
      {children}
    </label>
  );
}
