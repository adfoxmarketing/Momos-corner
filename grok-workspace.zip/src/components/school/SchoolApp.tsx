import { ArrowLeftRight, BookOpen, CalendarDays, GraduationCap, LayoutGrid, Moon, Sun, Table2, Wallet } from "lucide-react";
import { useEffect, useState } from "react";
import { Averages } from "@/components/school/Averages";
import { CalendarBoard } from "@/components/school/CalendarBoard";
import { Grading } from "@/components/school/Grading";
import { Timetable } from "@/components/school/Timetable";
import { Tutoring } from "@/components/school/Tutoring";
import { GhostButton, Mark, Modal, PrimaryButton, fieldClass } from "@/components/school/ui";
import { haptic } from "@/lib/school/format";
import { useSchool, useT } from "@/lib/school/store";

export function SchoolApp() {
  const school = useSchool();
  const t = useT();

  if (!school.ready) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg px-6 text-center text-fg">
        <div>
          <Mark className="mx-auto size-14 text-primary" />
          <p className="mt-3 text-lg font-bold">School Manager</p>
          <p className="text-sm text-muted">مدير المدرسة</p>
        </div>
      </main>
    );
  }

  if (school.bootError) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg px-6 text-center text-fg">
        <div>
          <p className="text-lg font-bold">{t("bootError")}</p>
          <p className="text-sm text-muted">{t("bootErrorAlt")}</p>
        </div>
      </main>
    );
  }

  if (!school.settings.activated) return <Activate />;
  if (!school.settings.role) return <RoleSelect />;
  return <Shell />;
}

function Activate() {
  const school = useSchool();
  const t = useT();
  const [key, setKey] = useState("");
  const [error, setError] = useState(false);

  const submit = async () => {
    try {
      const ok = await school.activate(key);
      if (!ok) {
        setError(true);
        haptic(20);
        return;
      }
      haptic(16);
    } catch (err) {
      console.error(err);
      setError(true);
    }
  };

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center bg-bg px-5 py-8 text-fg">
      <TopToggles />
      <div className="mt-6 rounded-2xl border border-border bg-surface p-6 shadow-lift">
        <Mark className="size-12 text-primary" />
        <p className="mt-4 text-xs font-semibold tracking-wide text-accent">{t("appNameAlt")}</p>
        <h1 className="text-3xl font-extrabold leading-tight">{t("appName")}</h1>
        <p className="mt-2 text-sm text-muted">{t("tagline")}</p>
        <h2 className="mt-6 text-lg font-bold">{t("activateTitle")}</h2>
        <p className="mt-1 text-sm text-muted">{t("activateHint")}</p>
        <label className="mt-4 block">
          <span className="mb-1 block text-sm font-medium">{t("licenseLabel")}</span>
          <input
            dir="ltr"
            autoCapitalize="characters"
            autoComplete="off"
            spellCheck={false}
            value={key}
            placeholder={t("licensePlaceholder")}
            onChange={(event) => {
              setKey(event.target.value);
              setError(false);
            }}
            className={`${fieldClass} text-center tracking-widest ${error ? "border-danger" : ""}`}
          />
        </label>
        {error ? <p className="mt-2 text-sm text-danger">{t("invalidLicense")}</p> : null}
        <div className="mt-4">
          <PrimaryButton onClick={() => void submit()}>{t("activate")}</PrimaryButton>
        </div>
        <p className="mt-4 text-xs text-muted" dir="ltr">
          {t("devKey")}
        </p>
      </div>
    </main>
  );
}

function RoleSelect() {
  const school = useSchool();
  const t = useT();
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col bg-bg px-5 py-6 text-fg">
      <TopToggles />
      <div className="mx-auto mt-8 w-full max-w-2xl">
        <Mark className="size-12 text-primary" />
        <h1 className="mt-4 text-3xl font-extrabold">{t("roleTitle")}</h1>
        <p className="mt-2 text-sm text-muted">{t("roleHint")}</p>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => {
              haptic(12);
              void school.setRole("student");
            }}
            className="press rounded-2xl border border-border bg-surface p-5 text-start hover:border-primary"
          >
            <BookOpen className="size-8 text-primary" />
            <span className="mt-4 block text-xl font-bold">{t("student")}</span>
            <span className="mt-1 block text-sm text-muted">{t("studentBlurb")}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              haptic(12);
              void school.setRole("teacher");
            }}
            className="press rounded-2xl border border-border bg-surface p-5 text-start hover:border-primary"
          >
            <GraduationCap className="size-8 text-accent" />
            <span className="mt-4 block text-xl font-bold">{t("teacher")}</span>
            <span className="mt-1 block text-sm text-muted">{t("teacherBlurb")}</span>
          </button>
        </div>
      </div>
    </main>
  );
}

function Shell() {
  const school = useSchool();
  const t = useT();
  const [tab, setTab] = useState("timetable");
  const [switching, setSwitching] = useState(false);
  const role = school.settings.role;

  useEffect(() => {
    setTab("timetable");
  }, [role]);

  const tabs =
    role === "teacher"
      ? [
          { id: "timetable", label: t("timetable"), icon: LayoutGrid },
          { id: "grading", label: t("grading"), icon: Table2 },
          { id: "tutoring", label: t("tutoring"), icon: Wallet },
        ]
      : [
          { id: "timetable", label: t("timetable"), icon: LayoutGrid },
          { id: "averages", label: t("averages"), icon: Table2 },
          { id: "calendar", label: t("calendar"), icon: CalendarDays },
        ];

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="h-1 bg-accent" />
      <header className="sticky top-0 z-30 flex items-center gap-1 border-b border-border bg-bg/90 px-2 py-1 backdrop-blur-md">
        <div className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary text-primary-fg">
          <Mark className="size-6" />
        </div>
        <div className="min-w-0 flex-1 px-1">
          <p className="truncate text-sm font-bold leading-tight">{t("appName")}</p>
          <p className="truncate text-xs text-muted">{role === "teacher" ? t("roleTeacher") : t("roleStudent")}</p>
        </div>
        <TopToggles />
        <button
          type="button"
          aria-label={t("switchRole")}
          onClick={() => setSwitching(true)}
          className="press grid size-11 place-items-center rounded-full hover:bg-surface-2"
        >
          <ArrowLeftRight className="size-5" />
        </button>
      </header>
      <main className="mx-auto w-full max-w-5xl px-3 pt-4 pb-28">
        {tab === "timetable" ? <Timetable /> : null}
        {tab === "averages" ? <Averages /> : null}
        {tab === "calendar" ? <CalendarBoard /> : null}
        {tab === "grading" ? <Grading /> : null}
        {tab === "tutoring" ? <Tutoring /> : null}
      </main>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 backdrop-blur-md">
        <div className="mx-auto grid max-w-lg grid-cols-3">
          {tabs.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={active ? "page" : undefined}
                onClick={() => {
                  haptic(8);
                  setTab(item.id);
                }}
                className={`press flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-semibold ${
                  active ? "text-primary" : "text-muted"
                }`}
              >
                <Icon className="size-5" />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
      {school.toast ? (
        <div className="pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <p className="rounded-full bg-fg px-4 py-2 text-sm font-medium text-bg shadow-lift">{school.toast}</p>
        </div>
      ) : null}
      {switching ? (
        <Modal title={t("switchRoleTitle")} onClose={() => setSwitching(false)}>
          <p className="mb-4 text-sm">{t("switchRoleBody")}</p>
          <div className="flex gap-2">
            <GhostButton onClick={() => setSwitching(false)}>{t("cancel")}</GhostButton>
            <PrimaryButton
              onClick={() => {
                const next = role === "teacher" ? "student" : "teacher";
                void school.setRole(next);
                haptic(12);
                setSwitching(false);
              }}
            >
              {role === "teacher" ? t("student") : t("teacher")}
            </PrimaryButton>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}

function TopToggles() {
  const school = useSchool();
  const t = useT();
  const dark = school.settings.theme === "dark";
  return (
    <div className="flex items-center">
      <button
        type="button"
        aria-label={t("language")}
        onClick={() => {
          haptic(8);
          void school.setLang(school.settings.lang === "ar" ? "en" : "ar");
        }}
        className="press grid h-11 min-w-11 place-items-center rounded-full px-2 text-sm font-bold hover:bg-surface-2"
      >
        {school.settings.lang === "ar" ? "EN" : "ع"}
      </button>
      <button
        type="button"
        aria-label={dark ? t("lightMode") : t("darkMode")}
        onClick={() => {
          haptic(8);
          void school.setTheme(dark ? "light" : "dark");
        }}
        className="press grid size-11 place-items-center rounded-full hover:bg-surface-2"
      >
        {dark ? <Sun className="size-5" /> : <Moon className="size-5" />}
      </button>
    </div>
  );
}
