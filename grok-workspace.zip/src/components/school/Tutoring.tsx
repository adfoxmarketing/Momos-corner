import { Plus } from "lucide-react";
import { useState } from "react";
import { Field, GhostButton, Modal, PrimaryButton, fieldClass } from "@/components/school/ui";
import { formatMoney, haptic, parseAmount } from "@/lib/school/format";
import { useSchool, useT } from "@/lib/school/store";
import type { TutoringStudent } from "@/lib/school/types";

export function Tutoring() {
  const school = useSchool();
  const t = useT();
  const [adding, setAdding] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const rows = [...school.tutoring].sort((a, b) => a.name.localeCompare(b.name, school.settings.lang));
  const billed = rows.reduce((sum, row) => sum + row.total_amount, 0);
  const collected = rows.reduce((sum, row) => sum + row.paid_amount, 0);
  const outstanding = billed - collected;

  return (
    <div>
      <p className="mb-3 text-sm text-muted">{t("tutoringHint")}</p>
      <section className="mb-4 grid grid-cols-3 gap-2">
        <Stat label={t("billed")} value={formatMoney(school.settings.lang, billed)} />
        <Stat label={t("collected")} value={formatMoney(school.settings.lang, collected)} />
        <Stat
          label={t("outstanding")}
          value={formatMoney(school.settings.lang, outstanding)}
          tone={outstanding > 0.009 ? "due" : "ok"}
        />
      </section>
      <div className="mb-3">
        <PrimaryButton
          onClick={() => {
            haptic(8);
            setAdding(true);
          }}
        >
          <Plus className="size-4" />
          {t("addTutoring")}
        </PrimaryButton>
      </div>
      {rows.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted">{t("noTutoring")}</p>
      ) : (
        <ul className="grid gap-2">
          {rows.map((row) => {
            const remaining = row.total_amount - row.paid_amount;
            const ratio = row.total_amount > 0 ? Math.min(1, row.paid_amount / row.total_amount) : row.paid_amount > 0 ? 1 : 0;
            return (
              <li key={row.id}>
                <button
                  type="button"
                  onClick={() => {
                    haptic(8);
                    setEditId(row.id);
                  }}
                  className="press w-full rounded-xl border border-border bg-surface p-3 text-start"
                >
                  <span className="flex items-start justify-between gap-3">
                    <span className="min-w-0">
                      <span className="block truncate font-semibold">{row.name}</span>
                      <span className="block truncate text-sm text-muted">
                        {row.group_name} · {row.location}
                      </span>
                    </span>
                    <span className="text-end">
                      <span className="block text-xs text-muted">{t("remaining")}</span>
                      <span className={`block text-lg font-bold tabular-nums ${remaining > 0.009 ? "text-danger" : "text-ok"}`}>
                        {formatMoney(school.settings.lang, remaining)}
                      </span>
                      <span className={`text-xs font-semibold ${remaining > 0.009 ? "text-danger" : "text-ok"}`}>
                        {remaining > 0.009 ? t("dueBalance") : t("settled")}
                      </span>
                    </span>
                  </span>
                  <span className="mt-3 grid grid-cols-2 gap-2 text-sm">
                    <span className="rounded-lg bg-surface-2 px-2 py-1.5">
                      <span className="block text-xs text-muted">{t("total")}</span>
                      <span className="font-semibold tabular-nums">{formatMoney(school.settings.lang, row.total_amount)}</span>
                    </span>
                    <span className="rounded-lg bg-surface-2 px-2 py-1.5">
                      <span className="block text-xs text-muted">{t("paid")}</span>
                      <span className="font-semibold tabular-nums">{formatMoney(school.settings.lang, row.paid_amount)}</span>
                    </span>
                  </span>
                  <span className="mt-3 block h-1.5 overflow-hidden rounded-full bg-surface-2">
                    <span className="block h-full bg-primary" style={{ width: `${ratio * 100}%` }} />
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
      {adding ? <AddTutoring onClose={() => setAdding(false)} /> : null}
      {editId != null ? <EditTutoring id={editId} onClose={() => setEditId(null)} /> : null}
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "due" | "ok" }) {
  return (
    <div className="rounded-xl border border-border bg-surface px-2 py-3 text-center">
      <p className="text-xs text-muted">{label}</p>
      <p className={`mt-1 text-sm font-bold tabular-nums ${tone === "due" ? "text-danger" : tone === "ok" ? "text-ok" : ""}`}>{value}</p>
    </div>
  );
}

function AddTutoring({ onClose }: { onClose: () => void }) {
  const school = useSchool();
  const t = useT();
  const [name, setName] = useState("");
  const [group, setGroup] = useState("");
  const [location, setLocation] = useState("");
  const [total, setTotal] = useState("");
  const [error, setError] = useState("");

  const save = async () => {
    const amount = parseAmount(total);
    if (!name.trim() || !group.trim() || !location.trim()) {
      setError(t("required"));
      return;
    }
    if (amount === "invalid") {
      setError(t("amountInvalid"));
      return;
    }
    try {
      await school.addTutoring({ name: name.trim(), group_name: group.trim(), location: location.trim(), total_amount: amount });
      haptic(12);
      school.flash(t("saved"));
      onClose();
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  return (
    <Modal title={t("addTutoring")} onClose={onClose}>
      <Field label={t("studentName")}>
        <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} />
      </Field>
      <Field label={t("group")}>
        <input className={fieldClass} value={group} onChange={(event) => setGroup(event.target.value)} />
      </Field>
      <Field label={t("location")}>
        <input className={fieldClass} value={location} onChange={(event) => setLocation(event.target.value)} />
      </Field>
      <Field label={t("total")}>
        <input dir="ltr" inputMode="decimal" className={fieldClass} value={total} onChange={(event) => setTotal(event.target.value)} />
      </Field>
      {error ? <p className="mb-3 text-sm text-danger">{error}</p> : null}
      <div className="flex gap-2">
        <GhostButton onClick={onClose}>{t("cancel")}</GhostButton>
        <PrimaryButton onClick={() => void save()}>{t("save")}</PrimaryButton>
      </div>
    </Modal>
  );
}

function EditTutoring({ id, onClose }: { id: number; onClose: () => void }) {
  const school = useSchool();
  const t = useT();
  const row = school.tutoring.find((student) => student.id === id);
  const [draft, setDraft] = useState<TutoringStudent | null>(row ?? null);
  const [paid, setPaid] = useState(row ? String(row.paid_amount) : "");
  const [total, setTotal] = useState(row ? String(row.total_amount) : "");
  const [error, setError] = useState("");
  const [confirm, setConfirm] = useState(false);
  if (!row || !draft) return null;
  const paidValue = parseAmount(paid);
  const totalValue = parseAmount(total);
  const remaining =
    paidValue !== "invalid" && totalValue !== "invalid" ? totalValue - paidValue : row.total_amount - row.paid_amount;

  const save = async () => {
    if (!draft.name.trim() || !draft.group_name.trim() || !draft.location.trim()) {
      setError(t("required"));
      return;
    }
    if (paidValue === "invalid" || totalValue === "invalid") {
      setError(t("amountInvalid"));
      return;
    }
    try {
      await school.updateTutoring({
        ...draft,
        name: draft.name.trim(),
        group_name: draft.group_name.trim(),
        location: draft.location.trim(),
        paid_amount: paidValue,
        total_amount: totalValue,
      });
      haptic(12);
      school.flash(t("saved"));
      onClose();
    } catch (err) {
      console.error(err);
      school.flash(t("errorGeneric"));
    }
  };

  return (
    <Modal title={t("updatePaid")} onClose={onClose}>
      <Field label={t("studentName")}>
        <input className={fieldClass} value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} />
      </Field>
      <Field label={t("group")}>
        <input className={fieldClass} value={draft.group_name} onChange={(event) => setDraft({ ...draft, group_name: event.target.value })} />
      </Field>
      <Field label={t("location")}>
        <input className={fieldClass} value={draft.location} onChange={(event) => setDraft({ ...draft, location: event.target.value })} />
      </Field>
      <Field label={t("total")}>
        <input dir="ltr" inputMode="decimal" className={fieldClass} value={total} onChange={(event) => setTotal(event.target.value)} />
      </Field>
      <Field label={t("paid")}>
        <input dir="ltr" inputMode="decimal" className={fieldClass} value={paid} onChange={(event) => setPaid(event.target.value)} />
      </Field>
      <p className={`mb-3 text-sm font-semibold ${remaining > 0.009 ? "text-danger" : "text-ok"}`}>
        {t("remaining")}: <span className="tabular-nums">{formatMoney(school.settings.lang, remaining)}</span>
      </p>
      {error ? <p className="mb-3 text-sm text-danger">{error}</p> : null}
      {confirm ? (
        <div className="flex gap-2">
          <GhostButton onClick={() => setConfirm(false)}>{t("cancel")}</GhostButton>
          <GhostButton
            danger
            onClick={() => {
              void school.deleteTutoring(row.id).then(() => {
                haptic(12);
                school.flash(t("deleted"));
                onClose();
              });
            }}
          >
            {t("delete")}
          </GhostButton>
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          <GhostButton onClick={onClose}>{t("cancel")}</GhostButton>
          <GhostButton danger onClick={() => setConfirm(true)}>{t("deleteStudent")}</GhostButton>
          <PrimaryButton onClick={() => void save()}>{t("save")}</PrimaryButton>
        </div>
      )}
    </Modal>
  );
}
