import { createFileRoute } from "@tanstack/react-router";
import { SchoolApp } from "@/components/school/SchoolApp";
import { SchoolProvider } from "@/lib/school/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <SchoolProvider>
      <SchoolApp />
    </SchoolProvider>
  );
}
