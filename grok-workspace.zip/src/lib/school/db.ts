const DB_NAME = "school_manager";
const DB_VERSION = 1;

const STORES = [
  "subjects",
  "class_slots",
  "tasks",
  "attachments",
  "student_grades",
  "calendar_notes",
  "teacher_sections",
  "teacher_terms",
  "teacher_grades",
  "tutoring_students",
] as const;

let opening: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (typeof indexedDB === "undefined") {
    return Promise.reject(new Error("IndexedDB unavailable"));
  }
  if (opening) return opening;
  opening = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta");
      for (const name of STORES) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: "id", autoIncrement: true });
        }
      }
      const tx = request.transaction;
      if (!tx) return;
      const notes = tx.objectStore("calendar_notes");
      if (!notes.indexNames.contains("date")) notes.createIndex("date", "date", { unique: true });
      const grades = tx.objectStore("student_grades");
      if (!grades.indexNames.contains("subject_id")) {
        grades.createIndex("subject_id", "subject_id", { unique: true });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => {
      opening = null;
      reject(request.error ?? new Error("Failed to open database"));
    };
  });
  return opening;
}

function finish(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("Transaction failed"));
    tx.onabort = () => reject(tx.error ?? new Error("Transaction aborted"));
  });
}

export async function getMeta<T>(key: string): Promise<T | undefined> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("meta", "readonly");
    const request = tx.objectStore("meta").get(key);
    request.onsuccess = () => resolve(request.result as T | undefined);
    request.onerror = () => reject(request.error ?? new Error("Meta read failed"));
  });
}

export async function setMeta(key: string, value: unknown): Promise<void> {
  const db = await openDb();
  const tx = db.transaction("meta", "readwrite");
  tx.objectStore("meta").put(value, key);
  await finish(tx);
}

export async function getAllRows<T>(store: string): Promise<T[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readonly");
    const request = tx.objectStore(store).getAll();
    request.onsuccess = () => resolve((request.result as T[]) ?? []);
    request.onerror = () => reject(request.error ?? new Error("Read failed"));
  });
}

export async function addRow<T extends object>(store: string, value: T): Promise<T & { id: number }> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    const request = tx.objectStore(store).add(value);
    request.onsuccess = () => resolve({ ...value, id: request.result as number });
    request.onerror = () => reject(request.error ?? new Error("Add failed"));
  });
}

export async function putRow<T extends { id: number }>(store: string, value: T): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(store, "readwrite");
  tx.objectStore(store).put(value);
  await finish(tx);
}

export async function deleteRow(store: string, id: number): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(store, "readwrite");
  tx.objectStore(store).delete(id);
  await finish(tx);
}

export async function deleteWhere<T extends { id: number }>(store: string, pred: (row: T) => boolean): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(store, "readwrite");
  const request = tx.objectStore(store).openCursor();
  request.onsuccess = () => {
    const cursor = request.result;
    if (!cursor) return;
    if (pred(cursor.value as T)) cursor.delete();
    cursor.continue();
  };
  await finish(tx);
}
