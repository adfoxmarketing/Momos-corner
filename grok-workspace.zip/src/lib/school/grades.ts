import type { Marks, MarkField } from "@/lib/school/types";

export const WEIGHTS: Record<MarkField, number> = {
  cc: 1,
  tp: 1,
  dev1: 1,
  dev2: 1,
  exam: 2,
};

export function averageOf(marks: Marks): number | null {
  let sum = 0;
  let weight = 0;
  (Object.keys(WEIGHTS) as MarkField[]).forEach((field) => {
    const value = marks[field];
    if (value == null || Number.isNaN(value)) return;
    sum += value * WEIGHTS[field];
    weight += WEIGHTS[field];
  });
  if (weight === 0) return null;
  return sum / weight;
}

export function generalAverage(items: { average: number | null; coefficient: number }[]): number | null {
  let sum = 0;
  let coef = 0;
  for (const item of items) {
    if (item.average == null) continue;
    const weight = item.coefficient > 0 ? item.coefficient : 1;
    sum += item.average * weight;
    coef += weight;
  }
  if (coef === 0) return null;
  return sum / coef;
}
