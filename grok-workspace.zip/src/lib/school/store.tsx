import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { addRow, deleteRow, deleteWhere, getAllRows, getMeta, putRow, setMeta } from "@/lib/school/db";
import { translate, type Key } from "@/lib/school/i18n";
import { formatDate, reminderTime } from "@/lib/school/format";
import {
  emptyMarks,
  type Attachment,
  type CalendarNote,
  type ClassSlot,
  type Lang,
  type Role,
  type Settings,
  type StudentGrade,
  type Subject,
  type Task,
  type TeacherGrade,
  type TeacherSection,
  type TeacherTerm,
  type Theme,
  type TutoringStudent,
  type MarkField,
} from "@/lib/school/types";

type SchoolState = {
  ready: boolean;
  bootError: boolean;
  settings: Settings;
  subjects: Subject[];
  slots: ClassSlot[];
  tasks: Task[];
  attachments: Attachment[];
  grades: StudentGrade[];
  notes: CalendarNote[];
  sections: TeacherSection[];
  terms: TeacherTerm[];
  teacherGrades: TeacherGrade[];
  tutoring: TutoringStudent[];
  toast: string | null;
};

const DEFAULT_SETTINGS: Settings = {
  activated: false,
  role: null,
  theme: "light",
  lang: "en",
  reminded: [],
};

const initialState: SchoolState = {
  ready: false,
  bootError: false,
  settings: DEFAULT_SETTINGS,
  subjects: [],
  slots: [],
  tasks: [],
  attachments: [],
  grades: [],
  notes: [],
  sections: [],
  terms: [],
  teacherGrades: [],
  tutoring: [],
  toast: null,
};

type ClassInput = {
  name: string;
  teacher: string;
  color: string;
  coefficient: number;
  day: number;
  start: string;
  end: string;
};

type SchoolApi = SchoolState & {
  flash: (message: string) => void;
  activate: (key: string) => Promise<boolean>;
  setRole: (role: Role) => Promise<void>;
  setLang: (lang: Lang) => Promise<void>;
  setTheme: (theme: Theme) => Promise<void>;
  saveClass: (input: ClassInput) => Promise<void>;
  deleteSlot: (id: number) => Promise<void>;
  addTask: (input: { subjectId: number; title: string; due: string }) => Promise<boolean>;
  toggleTask: (id: number, done: boolean) => Promise<void>;
  deleteTask: (id: number) => Promise<void>;
  addAttachment: (input: { subjectId: number; title: string; type: "image" | "pdf"; file: Blob; filename: string }) => Promise<void>;
  deleteAttachment: (id: number) => Promise<void>;
  setStudentMark: (subjectId: number, field: MarkField, value: number | null) => Promise<void>;
  saveNote: (date: string, note: string) => Promise<void>;
  addSection: (name: string) => Promise<void>;
  deleteSection: (id: number) => Promise<void>;
  addTerm: (name: string) => Promise<void>;
  deleteTerm: (id: number) => Promise<void>;
  addTeacherStudent: (input: { sectionId: number; termId: number; name: string }) => Promise<void>;
  updateTeacherGrade: (row: TeacherGrade) => Promise<void>;
  deleteTeacherGrade: (id: number) => Promise<void>;
  addTutoring: (input: { name: string; group_name: string; location: string; total_amount: number }) => Promise<void>;
  updateTutoring: (row: TutoringStudent) => Promise<void>;
  deleteTutoring: (id: number) => Promise<void>;
};

const SchoolContext = createContext<SchoolApi | null>(null);

function detectedSettings(): Settings {
  const theme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  const lang = navigator.language.toLowerCase().startsWith("ar") ? "ar" : "en";
  return { ...DEFAULT_SETTINGS, theme, lang };
}

async function ensureNotifyPermission(): Promise<boolean> {
  if (typeof Notification === "undefined") return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") return false;
  try {
    return (await Notification.requestPermission()) === "granted";
  } catch {
    return false;
  }
}

export function SchoolProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SchoolState>(initialState);
  const dataRef = useRef(state);
  const queue = useRef(Promise.resolve());
  const toastTimer = useRef<number | null>(null);

  const patch = (fn: (current: SchoolState) => SchoolState) => {
    setState((current) => {
      const next = fn(current);
      dataRef.current = next;
      return next;
    });
  };

  const flash = (message: string) => {
    patch((current) => ({ ...current, toast: message }));
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => {
      patch((current) => ({ ...current, toast: null }));
    }, 2600);
  };

  const enqueue = <T,>(fn: () => Promise<T>): Promise<T> => {
    const run = queue.current.then(fn, fn);
    queue.current = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  };

  const writeSettings = async (next: Settings) => {
    patch((current) => ({ ...current, settings: next }));
    await setMeta("settings", next);
  };

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const [saved, subjects, slots, tasks, attachments, grades, notes, sections, terms, teacherGrades, tutoring] =
          await Promise.all([
            getMeta<Settings>("settings"),
            getAllRows<Subject>("subjects"),
            getAllRows<ClassSlot>("class_slots"),
            getAllRows<Task>("tasks"),
            getAllRows<Attachment>("attachments"),
            getAllRows<StudentGrade>("student_grades"),
            getAllRows<CalendarNote>("calendar_notes"),
            getAllRows<TeacherSection>("teacher_sections"),
            getAllRows<TeacherTerm>("teacher_terms"),
            getAllRows<TeacherGrade>("teacher_grades"),
            getAllRows<TutoringStudent>("tutoring_students"),
          ]);
        if (cancelled) return;
        const settings = saved
          ? { ...DEFAULT_SETTINGS, ...saved, reminded: saved.reminded ?? [] }
          : detectedSettings();
        patch((current) => ({
          ...current,
          ready: true,
          settings,
          subjects,
          slots,
          tasks,
          attachments,
          grades,
          notes,
          sections,
          terms,
          teacherGrades,
          tutoring,
        }));
      } catch (error) {
        console.error(error);
        if (!cancelled) patch((current) => ({ ...current, ready: true, bootError: true }));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!state.ready) return;
    document.documentElement.classList.toggle("dark", state.settings.theme === "dark");
    document.documentElement.lang = state.settings.lang === "ar" ? "ar" : "en";
    document.documentElement.dir = state.settings.lang === "ar" ? "rtl" : "ltr";
    try {
      localStorage.setItem("sm-theme", state.settings.theme);
      localStorage.setItem("sm-lang", state.settings.lang);
    } catch {
      /* ignore quota */
    }
  }, [state.ready, state.settings.theme, state.settings.lang]);

  useEffect(() => {
    if (!state.ready) return;
    let cancelled = false;
    const run = () => {
      void enqueue(async () => {
        if (cancelled) return;
        const current = dataRef.current;
        const due = current.tasks.filter((task) => {
          if (task.is_completed || current.settings.reminded.includes(task.id)) return false;
          return Date.now() >= reminderTime(task.due_date);
        });
        if (!due.length) return;
        const permitted = typeof Notification !== "undefined" && Notification.permission === "granted";
        const lang = current.settings.lang;
        const message = translate(lang, "reminderBody", {
          title: due[0].title,
          date: formatDate(lang, due[0].due_date),
        });
        for (const task of due) {
          const body = translate(lang, "reminderBody", { title: task.title, date: formatDate(lang, task.due_date) });
          if (permitted) {
            try {
              new Notification(translate(lang, "reminderTitle"), { body });
            } catch {
              /* notification constructor can throw */
            }
          }
        }
        const reminded = [...current.settings.reminded, ...due.map((task) => task.id)];
        const next = { ...current.settings, reminded };
        patch((snapshot) => ({ ...snapshot, settings: next, toast: message }));
        if (toastTimer.current) window.clearTimeout(toastTimer.current);
        toastTimer.current = window.setTimeout(() => {
          patch((snapshot) => ({ ...snapshot, toast: null }));
        }, 3200);
        await setMeta("settings", next);
      });
    };
    run();
    const id = window.setInterval(run, 30000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [state.ready, state.tasks, state.settings.reminded, state.settings.lang]);

  const api = useMemo<SchoolApi>(() => {
    return {
      ...state,
      flash,
      activate: async (key) => {
        if (key.trim().toUpperCase() !== "TEST-DEV-2024") return false;
        await enqueue(() => writeSettings({ ...dataRef.current.settings, activated: true }));
        return true;
      },
      setRole: (role) => enqueue(() => writeSettings({ ...dataRef.current.settings, role })),
      setLang: (lang) => enqueue(() => writeSettings({ ...dataRef.current.settings, lang })),
      setTheme: (theme) => enqueue(() => writeSettings({ ...dataRef.current.settings, theme })),
      saveClass: (input) =>
        enqueue(async () => {
          const current = dataRef.current;
          const name = input.name.trim();
          const teacher = input.teacher.trim();
          const existing = current.subjects.find((subject) => subject.name.trim().toLowerCase() === name.toLowerCase());
          let subjectId: number;
          let subjects = current.subjects;
          if (existing) {
            const updated: Subject = {
              ...existing,
              teacher,
              color: input.color,
              coefficient: input.coefficient,
            };
            await putRow("subjects", updated);
            subjects = subjects.map((subject) => (subject.id === updated.id ? updated : subject));
            subjectId = updated.id;
          } else {
            const created = await addRow("subjects", {
              name,
              teacher,
              color: input.color,
              coefficient: input.coefficient,
            });
            subjects = [...subjects, created];
            subjectId = created.id;
          }
          const slot = await addRow("class_slots", {
            subject_id: subjectId,
            day_of_week: input.day,
            start_time: input.start,
            end_time: input.end,
          });
          patch((snapshot) => ({ ...snapshot, subjects, slots: [...snapshot.slots, slot] }));
        }),
      deleteSlot: (id) =>
        enqueue(async () => {
          await deleteRow("class_slots", id);
          patch((snapshot) => ({ ...snapshot, slots: snapshot.slots.filter((slot) => slot.id !== id) }));
        }),
      addTask: async (input) => {
        const permitted = await ensureNotifyPermission();
        await enqueue(async () => {
          const task = await addRow("tasks", {
            subject_id: input.subjectId,
            title: input.title.trim(),
            due_date: input.due,
            is_completed: false,
          });
          patch((snapshot) => ({ ...snapshot, tasks: [...snapshot.tasks, task] }));
        });
        return permitted;
      },
      toggleTask: (id, done) =>
        enqueue(async () => {
          const task = dataRef.current.tasks.find((item) => item.id === id);
          if (!task) return;
          const next = { ...task, is_completed: done };
          await putRow("tasks", next);
          patch((snapshot) => ({
            ...snapshot,
            tasks: snapshot.tasks.map((item) => (item.id === id ? next : item)),
          }));
        }),
      deleteTask: (id) =>
        enqueue(async () => {
          await deleteRow("tasks", id);
          patch((snapshot) => ({ ...snapshot, tasks: snapshot.tasks.filter((task) => task.id !== id) }));
        }),
      addAttachment: (input) =>
        enqueue(async () => {
          const today = new Date();
          const upload_date = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
          const row = await addRow("attachments", {
            subject_id: input.subjectId,
            title: input.title.trim(),
            type: input.type,
            file_path: input.filename,
            upload_date,
            blob: input.file,
          });
          patch((snapshot) => ({ ...snapshot, attachments: [...snapshot.attachments, row] }));
        }),
      deleteAttachment: (id) =>
        enqueue(async () => {
          await deleteRow("attachments", id);
          patch((snapshot) => ({
            ...snapshot,
            attachments: snapshot.attachments.filter((file) => file.id !== id),
          }));
        }),
      setStudentMark: (subjectId, field, value) =>
        enqueue(async () => {
          const existing = dataRef.current.grades.find((grade) => grade.subject_id === subjectId);
          if (!existing) {
            const created = await addRow("student_grades", { subject_id: subjectId, ...emptyMarks(), [field]: value });
            patch((snapshot) => ({ ...snapshot, grades: [...snapshot.grades, created] }));
            return;
          }
          const next: StudentGrade = { ...existing, [field]: value };
          await putRow("student_grades", next);
          patch((snapshot) => ({
            ...snapshot,
            grades: snapshot.grades.map((grade) => (grade.id === next.id ? next : grade)),
          }));
        }),
      saveNote: (date, note) =>
        enqueue(async () => {
          const text = note.trim();
          const existing = dataRef.current.notes.find((item) => item.date === date);
          if (!text) {
            if (!existing) return;
            await deleteRow("calendar_notes", existing.id);
            patch((snapshot) => ({ ...snapshot, notes: snapshot.notes.filter((item) => item.id !== existing.id) }));
            return;
          }
          if (existing) {
            const next = { ...existing, note: text };
            await putRow("calendar_notes", next);
            patch((snapshot) => ({
              ...snapshot,
              notes: snapshot.notes.map((item) => (item.id === next.id ? next : item)),
            }));
            return;
          }
          const created = await addRow("calendar_notes", { date, note: text });
          patch((snapshot) => ({ ...snapshot, notes: [...snapshot.notes, created] }));
        }),
      addSection: (name) =>
        enqueue(async () => {
          const row = await addRow("teacher_sections", { name: name.trim() });
          patch((snapshot) => ({ ...snapshot, sections: [...snapshot.sections, row] }));
        }),
      deleteSection: (id) =>
        enqueue(async () => {
          await deleteWhere<TeacherGrade>("teacher_grades", (row) => row.section_id === id);
          await deleteRow("teacher_sections", id);
          patch((snapshot) => ({
            ...snapshot,
            sections: snapshot.sections.filter((section) => section.id !== id),
            teacherGrades: snapshot.teacherGrades.filter((grade) => grade.section_id !== id),
          }));
        }),
      addTerm: (name) =>
        enqueue(async () => {
          const row = await addRow("teacher_terms", { name: name.trim() });
          patch((snapshot) => ({ ...snapshot, terms: [...snapshot.terms, row] }));
        }),
      deleteTerm: (id) =>
        enqueue(async () => {
          await deleteWhere<TeacherGrade>("teacher_grades", (row) => row.term_id === id);
          await deleteRow("teacher_terms", id);
          patch((snapshot) => ({
            ...snapshot,
            terms: snapshot.terms.filter((term) => term.id !== id),
            teacherGrades: snapshot.teacherGrades.filter((grade) => grade.term_id !== id),
          }));
        }),
      addTeacherStudent: (input) =>
        enqueue(async () => {
          const row = await addRow("teacher_grades", {
            section_id: input.sectionId,
            term_id: input.termId,
            student_name: input.name.trim(),
            ...emptyMarks(),
          });
          patch((snapshot) => ({ ...snapshot, teacherGrades: [...snapshot.teacherGrades, row] }));
        }),
      updateTeacherGrade: (row) =>
        enqueue(async () => {
          await putRow("teacher_grades", row);
          patch((snapshot) => ({
            ...snapshot,
            teacherGrades: snapshot.teacherGrades.map((grade) => (grade.id === row.id ? row : grade)),
          }));
        }),
      deleteTeacherGrade: (id) =>
        enqueue(async () => {
          await deleteRow("teacher_grades", id);
          patch((snapshot) => ({
            ...snapshot,
            teacherGrades: snapshot.teacherGrades.filter((grade) => grade.id !== id),
          }));
        }),
      addTutoring: (input) =>
        enqueue(async () => {
          const row = await addRow("tutoring_students", { ...input, paid_amount: 0 });
          patch((snapshot) => ({ ...snapshot, tutoring: [...snapshot.tutoring, row] }));
        }),
      updateTutoring: (row) =>
        enqueue(async () => {
          await putRow("tutoring_students", row);
          patch((snapshot) => ({
            ...snapshot,
            tutoring: snapshot.tutoring.map((student) => (student.id === row.id ? row : student)),
          }));
        }),
      deleteTutoring: (id) =>
        enqueue(async () => {
          await deleteRow("tutoring_students", id);
          patch((snapshot) => ({ ...snapshot, tutoring: snapshot.tutoring.filter((student) => student.id !== id) }));
        }),
    };
    // flash/enqueue close over refs; state identity drives a fresh api.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return <SchoolContext.Provider value={api}>{children}</SchoolContext.Provider>;
}

export function useSchool(): SchoolApi {
  const ctx = useContext(SchoolContext);
  if (!ctx) throw new Error("useSchool must be used inside SchoolProvider");
  return ctx;
}

export function useT() {
  const { settings } = useSchool();
  return (key: Key, vars?: Record<string, string | number>) => translate(settings.lang, key, vars);
}
