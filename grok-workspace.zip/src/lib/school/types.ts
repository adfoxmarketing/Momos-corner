export type Role = "teacher" | "student";
export type Lang = "en" | "ar";
export type Theme = "light" | "dark";
export type AttachmentType = "image" | "pdf";
export type MarkField = "cc" | "tp" | "dev1" | "dev2" | "exam";

export type Marks = Record<MarkField, number | null>;

export type Settings = {
  activated: boolean;
  role: Role | null;
  theme: Theme;
  lang: Lang;
  reminded: number[];
};

export type Subject = {
  id: number;
  name: string;
  teacher: string;
  color: string;
  coefficient: number;
};

export type ClassSlot = {
  id: number;
  subject_id: number;
  day_of_week: number;
  start_time: string;
  end_time: string;
};

export type Task = {
  id: number;
  subject_id: number;
  title: string;
  due_date: string;
  is_completed: boolean;
};

export type Attachment = {
  id: number;
  subject_id: number;
  title: string;
  type: AttachmentType;
  file_path: string;
  upload_date: string;
  blob: Blob;
};

export type StudentGrade = Marks & {
  id: number;
  subject_id: number;
};

export type CalendarNote = {
  id: number;
  date: string;
  note: string;
};

export type TeacherSection = { id: number; name: string };
export type TeacherTerm = { id: number; name: string };

export type TeacherGrade = Marks & {
  id: number;
  section_id: number;
  term_id: number;
  student_name: string;
};

export type TutoringStudent = {
  id: number;
  name: string;
  group_name: string;
  location: string;
  total_amount: number;
  paid_amount: number;
};

export const MARK_FIELDS: MarkField[] = ["cc", "tp", "dev1", "dev2", "exam"];

export function emptyMarks(): Marks {
  return { cc: null, tp: null, dev1: null, dev2: null, exam: null };
}
