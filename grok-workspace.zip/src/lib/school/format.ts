import type { Lang } from "@/lib/school/types";

export const START_HOUR = 8;
export const SLOT_COUNT = 13;
export const DAY_START = START_HOUR * 60;
export const DAY_END = (START_HOUR + SLOT_COUNT) * 60;

export const SUBJECT_COLORS = [
  "#1e4d3a",
  "#a24b24",
  "#1d4e89",
  "#6b3fa0",
  "#8a5a12",
  "#0f6e6b",
  "#9b2c4a",
  "#3f6212",
];

export function localeOf(lang: Lang): string {
  return lang === "ar" ? "ar-u-nu-latn" : "en";
}

export function toHHMM(mins: number): string {
  const clamped = Math.max(0, mins);
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export function toMin(hhmm: string): number {
  const [h, m] = hhmm.split(":").map((part) => Number(part));
  if (!Number.isFinite(h) || !Number.isFinite(m)) return DAY_START;
  return h * 60 + m;
}

export function timeOptions(): string[] {
  const out: string[] = [];
  for (let m = DAY_START; m <= DAY_END; m += 30) out.push(toHHMM(m));
  return out;
}

export function hourLabels(): number[] {
  return Array.from({ length: SLOT_COUNT }, (_, i) => START_HOUR + i);
}

export function weekdayName(lang: Lang, dayOfWeek: number, width: "short" | "long" = "short"): string {
  const date = new Date(2023, 0, dayOfWeek);
  return new Intl.DateTimeFormat(localeOf(lang), { weekday: width }).format(date);
}

export function monthName(lang: Lang, monthIndex: number, width: "short" | "long" = "short"): string {
  return new Intl.DateTimeFormat(localeOf(lang), { month: width }).format(new Date(2023, monthIndex, 1));
}

export function formatDate(lang: Lang, iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return iso;
  return new Intl.DateTimeFormat(localeOf(lang), { dateStyle: "medium" }).format(new Date(y, m - 1, d));
}

export function formatMark(lang: Lang, value: number): string {
  return new Intl.NumberFormat(localeOf(lang), { maximumFractionDigits: 2 }).format(value);
}

export function formatMoney(lang: Lang, value: number): string {
  return new Intl.NumberFormat(localeOf(lang), { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
}

export function isoDate(year: number, monthIndex: number, day: number): string {
  return `${year}-${String(monthIndex + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

export function todayIso(): string {
  const now = new Date();
  return isoDate(now.getFullYear(), now.getMonth(), now.getDate());
}

export function tomorrowIso(): string {
  const now = new Date();
  now.setDate(now.getDate() + 1);
  return isoDate(now.getFullYear(), now.getMonth(), now.getDate());
}

export function reminderTime(dueIso: string): number {
  const [y, m, d] = dueIso.split("-").map(Number);
  const when = new Date(y || 1970, (m || 1) - 1, d || 1, 9, 0, 0, 0);
  when.setDate(when.getDate() - 1);
  return when.getTime();
}

export function foregroundFor(hex: string): string {
  const raw = hex.replace("#", "");
  if (!/^[0-9a-fA-F]{6}$/.test(raw)) return "#1c1915";
  const n = Number.parseInt(raw, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return luminance > 0.64 ? "#1c1915" : "#f7f4ee";
}

export function parseMark(raw: string): number | null | "invalid" {
  const text = raw.trim().replace(",", ".");
  if (!text) return null;
  const n = Number(text);
  if (!Number.isFinite(n) || n < 0 || n > 20) return "invalid";
  return Math.round(n * 100) / 100;
}

export function parseAmount(raw: string): number | "invalid" {
  const text = raw.trim().replace(",", ".");
  if (!text) return "invalid";
  const n = Number(text);
  if (!Number.isFinite(n) || n < 0) return "invalid";
  return Math.round(n * 100) / 100;
}

export function csvCell(value: string | number | null | undefined): string {
  const text = value == null ? "" : String(value);
  if (/[",\n\r]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}

export async function shareCsv(filename: string, rows: (string | number | null)[][]): Promise<"shared" | "downloaded" | "cancelled"> {
  const csv = rows.map((row) => row.map((cell) => csvCell(cell)).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
  const file = new File([blob], filename, { type: "text/csv" });
  try {
    if (typeof navigator.share === "function" && navigator.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], title: filename });
      return "shared";
    }
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
  return "downloaded";
}

export function clampZoom(value: number): number {
  return Math.min(1.8, Math.max(0.7, Math.round(value * 100) / 100));
}

export function haptic(ms = 12): void {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* unsupported */
  }
}
